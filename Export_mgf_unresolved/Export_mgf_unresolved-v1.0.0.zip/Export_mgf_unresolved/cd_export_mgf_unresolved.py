# -*- coding: utf-8 -*-
"""
cd_export_mgf_unresolved.py

Compound Discoverer Scripting Node helper for unresolved export.

Goal
----
Export Compound Discoverer results to MGF/feature-table-friendly files without
applying ion-redundancy resolution:

    1) <result_name>_spectra.mgf
    2) <result_name>_quant.csv
    3) <result_name>_metadata.tsv
    4) <result_name>_audit.xlsx

This script is designed to be run inside a Compound Discoverer Scripting Node:

    python cd_export_mgf_unresolved.py %NODEARGS%

What it does
------------
- Reads the Scripting Node JSON argument file.
- Reads the exported CD Compounds table.
- Opens the .cdResult SQLite file.
- Retrieves a recoverable MS/MS spectrum and its linked CD feature/ion identifier when available.
- Applies the same sample/blank ratio rule used for the unresolved comparison output.
- Writes an MGF where SCANS matches the quantification-table row ID and FEATURE_ID
  reports the linked CD feature/ion identifier when available.
- Writes the corresponding quantitative table, metadata table, and audit workbook.
- Does not perform ion-redundancy resolution, same-RT collapsing, representative-ion
  switching, or MS2-purity filtering. MS2 purity may still be recorded as an audit annotation.

Reproducibility note
--------------------
Legacy runtime labels containing "non-cleaned"/"non_cleaned" are intentionally retained
in generated reports and audit fields so that this public-release source produces the same
outputs as the analysis version. The public workflow name is "unresolved".

Important
---------
Request/export the upper Compounds table from CD with at least:
    Compounds ID, mz, RT in min, Reference Ion
and preferably the sample area columns.

If your CD table uses different names, this script tries common variants.
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import sys
import tempfile
import traceback
import zipfile
from datetime import datetime
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Iterable, List, Optional, Tuple

import pandas as pd


# ---------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(s).strip().lower())


def safe_float(value, default=None):
    try:
        if value is None or pd.isna(value):
            return default
        txt = str(value).strip().replace(",", ".")
        if txt == "":
            return default
        return float(txt)
    except Exception:
        return default


def safe_int(value, default=None):
    try:
        f = safe_float(value, None)
        if f is None:
            return default
        return int(f)
    except Exception:
        return default


def first_existing_col(df: pd.DataFrame, candidates: Iterable[str]) -> Optional[str]:
    cmap = {norm(c): c for c in df.columns}
    for c in candidates:
        if norm(c) in cmap:
            return cmap[norm(c)]
    return None


def read_table_auto(path: str) -> pd.DataFrame:
    try:
        return pd.read_csv(path, sep="\t", dtype=str, keep_default_na=False)
    except Exception:
        return pd.read_csv(path, sep=None, engine="python", dtype=str, keep_default_na=False)


def qident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def get_tables(con: sqlite3.Connection) -> List[str]:
    q = "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    return pd.read_sql_query(q, con)["name"].tolist()


def get_cols(con: sqlite3.Connection, table: str) -> List[str]:
    return pd.read_sql_query(f'PRAGMA table_info({qident(table)})', con)["name"].tolist()


# ---------------------------------------------------------------------
# Node argument and CD table handling
# ---------------------------------------------------------------------


def load_node_args() -> Tuple[dict, str, List[str]]:
    if len(sys.argv) < 2:
        raise RuntimeError("Expected %NODEARGS% JSON path as first argument.")

    node_args_file = sys.argv[1]
    with open(node_args_file, "r", encoding="utf-8-sig") as f:
        node_args = json.load(f)

    cdresult_file = node_args.get("ResultFilePath") or node_args.get("ResultFile") or ""
    if not cdresult_file:
        for v in node_args.values():
            if isinstance(v, str) and v.lower().endswith(".cdresult"):
                cdresult_file = v
                break

    table_paths = []
    tables = node_args.get("Tables", [])
    if isinstance(tables, list):
        for t in tables:
            if isinstance(t, dict):
                p = t.get("DataFile") or t.get("File") or t.get("Path") or t.get("FilePath")
                if p:
                    table_paths.append(p)
            elif isinstance(t, str):
                table_paths.append(t)

    return node_args, cdresult_file, table_paths


def find_compounds_table(table_paths: List[str]) -> Tuple[pd.DataFrame, str]:
    best_df = None
    best_path = ""
    best_score = -1

    for p in table_paths:
        if not p or not os.path.exists(p):
            continue
        try:
            df = read_table_auto(p)
        except Exception:
            continue

        cols_norm = {norm(c) for c in df.columns}
        score = 0
        for expected in ["compoundsid", "compoundid", "id", "rtinmin", "mz", "referenceion"]:
            if expected in cols_norm:
                score += 1
        if any("compound" in norm(c) for c in df.columns):
            score += 1

        if score > best_score:
            best_df = df
            best_path = p
            best_score = score

    if best_df is None:
        raise RuntimeError("Could not find an exported CD Compounds table in NODEARGS.")
    return best_df, best_path


def detect_required_columns(df: pd.DataFrame) -> dict:
    cols = {
        "compound_id": first_existing_col(df, ["Compounds ID", "Compound ID", "ID"]),
        "mz": first_existing_col(df, ["mz", "m/z", "Mass", "Mass to Charge", "Precursor m/z"]),
        "rt_min": first_existing_col(df, ["RT in min", "RT [min]", "Retention Time", "RetentionTime", "Apex RT"]),
        "reference_ion": first_existing_col(df, ["Reference Ion", "Ion", "Ion Type", "Adduct", "Best Ion"]),
        "area_max": first_existing_col(df, [
            "Area (Max.)", "Area Max", "Area Max.", "AreaMax", "Max Area", "MaxArea",
            "Maximum Area", "Area Maximum"
        ]),
        "calc_mw": first_existing_col(df, [
            "Calc. MW", "Calc MW", "Calculated MW", "Calculated Molecular Weight",
            "Molecular Weight", "MW", "Monoisotopic Mass", "Neutral Mass"
        ]),
        "formula": first_existing_col(df, ["Molecular Formula", "Formula"]),
        "name": first_existing_col(df, ["Name", "Compound Name", "Preferred Name", "Annotation"]),
    }
    missing = [k for k in ["compound_id", "mz", "rt_min"] if cols[k] is None]
    if missing:
        raise RuntimeError(
            "Missing required columns in CD table: {}. Available columns: {}".format(
                missing, list(df.columns)
            )
        )
    return cols


def detect_ms2_purity_column(df: pd.DataFrame) -> Optional[str]:
    """Detect a Compound Discoverer MS2 purity column, if it was exported.

    The exact CD display name can vary. This function intentionally does not
    make the column mandatory, because CD may refuse some requested column names
    before the Python script starts. If the column is present, the purity filter
    is applied; if it is absent, the script continues and records this in audit.
    """
    return first_existing_col(df, [
        "MS2 Purity [%]", "MS2 Purity", "MS2Purity", "MS2 Purity Percent",
        "MS/MS Purity", "MSMS Purity", "MSn Purity", "MSN Purity",
        "Isolation Purity", "Precursor Purity", "Purity [%]", "Purity"
    ])


def normalize_purity_percent(value, default=None):
    """Return MS2 purity as percent. Accepts either 0-100 or 0-1 values."""
    v = safe_float(value, default)
    if v is None or pd.isna(v):
        return default
    if 0.0 < float(v) <= 1.0:
        return float(v) * 100.0
    return float(v)


def get_ms2_spectrum_info_ids_for_compound(cid, con: sqlite3.Connection) -> List[int]:
    """Return MassSpectrumInfoItems IDs for MS2 spectra linked to a CD compound ID.

    This mirrors the same Compound Discoverer linkage used by get_best_scan_ms2().
    It is used only to retrieve spectrum-level fields such as MS2 purity when the
    Scripting Node does not export the visible Compounds table column.
    """
    if cid is None:
        return []
    query = """
        SELECT MassSpectrumInfoItems.ID
        FROM ConsolidatedUnknownCompoundItems,
             ConsolidatedUnknownCompoundItemsBestHitIonInstanceItems,
             BestHitIonInstanceItems,
             BestHitIonInstanceItemsMassSpectrumInfoItems,
             MassSpectrumInfoItems
        WHERE ConsolidatedUnknownCompoundItems.ID =
              ConsolidatedUnknownCompoundItemsBestHitIonInstanceItems.ConsolidatedUnknownCompoundItemsID
          AND BestHitIonInstanceItems.ID =
              ConsolidatedUnknownCompoundItemsBestHitIonInstanceItems.BestHitIonInstanceItemsID
          AND BestHitIonInstanceItemsMassSpectrumInfoItems.BestHitIonInstanceItemsID =
              BestHitIonInstanceItems.ID
          AND BestHitIonInstanceItemsMassSpectrumInfoItems.MassSpectrumInfoItemsID =
              MassSpectrumInfoItems.ID
          AND ConsolidatedUnknownCompoundItems.ID = ?
          AND MassSpectrumInfoItems.MSOrder = 2
        ORDER BY MassSpectrumInfoItems.ID
    """
    try:
        qres = pd.read_sql_query(query, con, params=[int(cid)])
        if qres.empty or "ID" not in qres.columns:
            return []
        return [int(x) for x in qres["ID"].dropna().tolist()]
    except Exception:
        return []


def get_purity_candidate_columns(cols: List[str]) -> List[str]:
    """Return possible SQLite columns carrying MS2/isolation purity.

    CD display columns can be computed from spectrum-level fields and may not use
    the exact name 'MS2 Purity'. This deliberately accepts any column containing
    'purity' and a few isolation/precursor variants.
    """
    out = []
    for c in cols:
        n = norm(c)
        if "purity" in n:
            out.append(c)
        elif "isolation" in n and any(tok in n for tok in ["percent", "pct", "ratio", "score"]):
            out.append(c)
        elif "precursor" in n and any(tok in n for tok in ["pur", "isolation"]):
            out.append(c)
    return out


def find_sqlite_ms2_purity_for_compound(cid, cdresult_file):
    """Try to retrieve CD MS2 Purity [%] directly from the .cdResult SQLite file.

    Strategy:
      1) Find the MS2 MassSpectrumInfoItems linked to the compound and search
         spectrum-level purity columns there. This is the most likely source of
         the visible 'MS2 Purity [%]' value in the Compounds table.
      2) Fall back to compound/ion/best-hit tables using CD compound ID columns.
    """
    if cid is None or not cdresult_file or not os.path.exists(cdresult_file):
        return None, "none"

    try:
        with sqlite3.connect(cdresult_file) as con:
            # First, look at the MassSpectrumInfoItems rows linked to this compound.
            spectrum_info_ids = get_ms2_spectrum_info_ids_for_compound(cid, con)
            for table in ["MassSpectrumInfoItems", "MassSpectrumItems"]:
                if table not in get_tables(con):
                    continue
                try:
                    cols = get_cols(con, table)
                except Exception:
                    continue
                purity_cols = get_purity_candidate_columns(cols)
                if not purity_cols or "ID" not in cols:
                    continue
                for spectrum_id in spectrum_info_ids:
                    for sqlite_purity_col in purity_cols:
                        try:
                            q = f"SELECT {qident(sqlite_purity_col)} AS purity_value FROM {qident(table)} WHERE {qident('ID')} = ? LIMIT 1"
                            df = pd.read_sql_query(q, con, params=[int(spectrum_id)])
                            if df.empty:
                                continue
                            value = normalize_purity_percent(df.iloc[0]["purity_value"], None)
                            if value is not None and not pd.isna(value):
                                return value, f"sqlite:{table}.{sqlite_purity_col};MassSpectrumInfoItemsID={spectrum_id}"
                        except Exception:
                            continue

            # Fallback: search compound/ion/best-hit tables directly by compound-like IDs.
            preferred_tables = [
                "ConsolidatedUnknownCompoundItems",
                "UnknownCompoundItems",
                "CompoundItems",
                "BestHitIonInstanceItems",
                "ConsolidatedUnknownCompoundIonItems",
                "MassSpectrumInfoItems",
                "MassSpectrumItems",
            ]
            compound_id_norms = {
                "id",
                "consolidatedunknowncompounditemsid",
                "unknowncompounditemsid",
                "compounditemsid",
                "compoundid",
                "compoundsid",
            }
            table_names = get_tables(con)
            ordered_tables = [t for t in preferred_tables if t in table_names] + [t for t in table_names if t not in preferred_tables]
            for table in ordered_tables:
                try:
                    cols = get_cols(con, table)
                except Exception:
                    continue
                if not cols:
                    continue

                purity_cols = get_purity_candidate_columns(cols)
                if not purity_cols:
                    continue

                id_cols = [c for c in cols if norm(c) in compound_id_norms]
                if table in {"ConsolidatedUnknownCompoundItems", "UnknownCompoundItems", "CompoundItems"} and "ID" in cols:
                    id_cols = ["ID"] + [c for c in id_cols if c != "ID"]

                for id_col in id_cols:
                    for sqlite_purity_col in purity_cols:
                        try:
                            q = f"SELECT {qident(sqlite_purity_col)} AS purity_value FROM {qident(table)} WHERE {qident(id_col)} = ? LIMIT 1"
                            df = pd.read_sql_query(q, con, params=[int(cid)])
                            if df.empty:
                                continue
                            value = normalize_purity_percent(df.iloc[0]["purity_value"], None)
                            if value is not None and not pd.isna(value):
                                return value, f"sqlite:{table}.{sqlite_purity_col}"
                        except Exception:
                            continue
    except Exception:
        return None, "none"

    return None, "none"


def detect_sample_area_columns(df: pd.DataFrame, required_cols: dict) -> List[str]:
    non_sample = {c for c in required_cols.values() if c}
    sample_cols = []

    patterns = [
        "area", "abundance", "height", "intensity", "normalizedarea", "peakarea"
    ]

    for col in df.columns:
        n = norm(col)
        if col in non_sample:
            continue
        if any(p in n for p in patterns):
            # Exclude obvious non-sample summary columns if possible.
            if any(x in n for x in ["max", "mean", "median", "rsd", "cv", "blankflag"]):
                continue
            sample_cols.append(col)

    # If no sample columns are detected, the quant table still benefits from a dummy column
    # so that the quant table remains structurally valid.
    return sample_cols


def is_blank_sample_name(name: str) -> bool:
    """Return True for blank/solvent/control blank sample names or CD area columns."""
    n = norm(name)
    blank_tokens = ["blank", "bianco", "blanc", "blk", "solventblank", "methodblank"]
    return any(tok in n for tok in blank_tokens)


def split_blank_and_nonblank_samples(sample_cols: List[str], sample_filenames: List[str]) -> Tuple[List[str], List[str], List[str], List[str]]:
    """Split sample area columns into blank and non-blank columns.

    Returns:
        nonblank_cols, nonblank_filenames, blank_cols, blank_filenames
    """
    nonblank_cols = []
    nonblank_filenames = []
    blank_cols = []
    blank_filenames = []

    for col, fname in zip(sample_cols, sample_filenames):
        if is_blank_sample_name(col) or is_blank_sample_name(fname):
            blank_cols.append(col)
            blank_filenames.append(fname)
        else:
            nonblank_cols.append(col)
            nonblank_filenames.append(fname)

    return nonblank_cols, nonblank_filenames, blank_cols, blank_filenames


def filter_out_blank_present_features(
    df: pd.DataFrame,
    nonblank_cols: List[str],
    blank_cols: List[str],
    ratio_threshold: float = 5.0,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Remove CD-like background features using a sample/blank ratio rule.

    A feature is removed only when it is present in at least one blank AND the
    strongest non-blank sample signal is not sufficiently higher than the
    strongest blank signal:

        max_blank_area > 0 and max_sample_area / max_blank_area <= ratio_threshold

    This mirrors the Compound Discoverer Mark Background concept more closely
    than the previous strict rule where any positive blank area removed a row.
    If no non-blank sample area columns are available, max_sample_area is treated
    as 0 for the ratio calculation.
    """
    if df.empty or not blank_cols:
        return df.copy(), df.iloc[0:0].copy()

    work = df.copy()

    blank_area_frame = work[blank_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)
    max_blank_area = blank_area_frame.max(axis=1)

    if nonblank_cols:
        sample_area_frame = work[nonblank_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)
        max_sample_area = sample_area_frame.max(axis=1)
    else:
        max_sample_area = pd.Series(0.0, index=work.index)

    sample_blank_ratio = pd.Series(float("inf"), index=work.index, dtype=float)
    positive_blank = max_blank_area > 0.0
    sample_blank_ratio.loc[positive_blank] = (
        max_sample_area.loc[positive_blank] / max_blank_area.loc[positive_blank]
    )

    remove_as_background = positive_blank & (sample_blank_ratio <= float(ratio_threshold))

    kept = work.loc[~remove_as_background].copy()
    removed = work.loc[remove_as_background].copy()
    return kept, removed

def clean_sample_filename(col: str) -> str:
    """Convert a Compound Discoverer area column into a metadata filename.

    Examples:
        Area MIXACIDI_10UGMlraw F3      -> MIXACIDI_10UGMl.raw
        Area BLANK_20230327235046raw F4 -> BLANK_20230327235046.raw
        Sample1.raw Area                -> Sample1.raw
    """
    name = str(col).strip()
    name = re.sub(r"\s*\(.*?\)\s*", "", name)
    name = re.sub(r"^(Area|Height|Intensity|Abundance)(?:\s*:\s*|\s+)", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\s+(Area|Height|Intensity|Abundance)$", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\s+F\d+(?:\.(?:raw|mzml|mzxml|cdf))?$", "", name, flags=re.IGNORECASE)
    name = name.replace("\\", "/").split("/")[-1].strip()

    # CD sometimes removes the dot before raw/mzML in exported area column names.
    name = re.sub(r"(?i)(?<!\.)raw$", ".raw", name)
    name = re.sub(r"(?i)mzml$", ".mzML", name)
    name = re.sub(r"(?i)mzxml$", ".mzXML", name)

    if not re.search(r"\.(raw|mzml|mzxml|cdf)$", name, flags=re.IGNORECASE):
        name = name + ".raw"
    return name


# ---------------------------------------------------------------------
# Ion/adduct parsing
# ---------------------------------------------------------------------


def parse_reference_ion(reference_ion):
    if reference_ion is None or pd.isna(reference_ion) or str(reference_ion).strip() == "":
        return "[Unknown]", 1, "+", "1+"

    ref = str(reference_ion).strip()
    ion_match = re.search(r"(\[.*?\][+-])", ref)
    ion_type = ion_match.group(1) if ion_match else ref

    polarity = "-" if ion_type.endswith("-") else "+"
    charge_abs = 1

    m1 = re.search(r"([+-])(\d+)$", ref)
    m2 = re.search(r"(\d+)([+-])$", ref)

    if m1:
        polarity = m1.group(1)
        charge_abs = int(m1.group(2))
    elif m2:
        charge_abs = int(m2.group(1))
        polarity = m2.group(2)
    else:
        if "+3H" in ref or "-3H" in ref:
            charge_abs = 3
        elif "+2H" in ref or "-2H" in ref:
            charge_abs = 2

    return ion_type, charge_abs, polarity, f"{charge_abs}{polarity}"


def canonical_ion_label(reference_ion: str) -> str:
    """Return the clean adduct label used for molecular-ion preference.

    Examples:
        [M+H]+1  -> [M+H]+
        [M-H]-1  -> [M-H]-
        [M+Na]+1 -> [M+Na]+
    """
    ion_type, _, _, _ = parse_reference_ion(reference_ion)
    return str(ion_type).replace(" ", "").upper()


# ---------------------------------------------------------------------
# MS/MS extraction from CD SQLite spectrum blobs
# ---------------------------------------------------------------------


def get_spectra_from_xml(zspec):
    if zspec is None:
        return pd.DataFrame(columns=["mz", "intensity"]), pd.DataFrame(columns=["mz", "intensity"])

    with tempfile.TemporaryDirectory() as tmpdir:
        zip_path = os.path.join(tmpdir, "spec.zip")
        with open(zip_path, "wb") as f:
            f.write(zspec)

        with zipfile.ZipFile(zip_path, "r") as z:
            names = z.namelist()
            if not names:
                return pd.DataFrame(columns=["mz", "intensity"]), pd.DataFrame(columns=["mz", "intensity"])
            z.extractall(tmpdir)
            xml_file = os.path.join(tmpdir, names[0])

        tree = ET.parse(xml_file)
        root = tree.getroot()

        ms2 = []
        for peak in root.findall(".//PeakCentroids/Peak"):
            mz = safe_float(peak.get("X"))
            intensity = safe_float(peak.get("Y"))
            if mz is not None and intensity is not None:
                ms2.append({"mz": mz, "intensity": intensity})

        isotope = []
        for peak in root.findall(".//IsotopeClusterPeakCentroids/Peak"):
            mz = safe_float(peak.get("X"))
            intensity = safe_float(peak.get("Y"))
            if mz is not None and intensity is not None:
                isotope.append({"mz": mz, "intensity": intensity})

        return (
            pd.DataFrame(ms2, columns=["mz", "intensity"]),
            pd.DataFrame(isotope, columns=["mz", "intensity"]),
        )


def get_best_scan_ms2(cid, cdresult_file):
    """Return MS2 and isotope DataFrames for one compound ID.

    The first query matches common CD 3.4/3.5 schemas. If it fails because
    a schema variant is different, the caller records diagnostics.
    """
    query = """
        SELECT MassSpectrumInfoItems.ID
        FROM ConsolidatedUnknownCompoundItems,
             ConsolidatedUnknownCompoundItemsBestHitIonInstanceItems,
             BestHitIonInstanceItems,
             BestHitIonInstanceItemsMassSpectrumInfoItems,
             MassSpectrumInfoItems
        WHERE ConsolidatedUnknownCompoundItems.ID =
              ConsolidatedUnknownCompoundItemsBestHitIonInstanceItems.ConsolidatedUnknownCompoundItemsID
          AND BestHitIonInstanceItems.ID =
              ConsolidatedUnknownCompoundItemsBestHitIonInstanceItems.BestHitIonInstanceItemsID
          AND BestHitIonInstanceItemsMassSpectrumInfoItems.BestHitIonInstanceItemsID =
              BestHitIonInstanceItems.ID
          AND BestHitIonInstanceItemsMassSpectrumInfoItems.MassSpectrumInfoItemsID =
              MassSpectrumInfoItems.ID
          AND ConsolidatedUnknownCompoundItems.ID = ?
          AND MassSpectrumInfoItems.MSOrder = 2
    """

    with sqlite3.connect(cdresult_file) as con:
        qres = pd.read_sql_query(query, con, params=[int(cid)])
        if qres.empty:
            return None, None

        spectrum_id = int(qres.iloc[0]["ID"])
        spectrum_query = "SELECT Spectrum FROM MassSpectrumItems WHERE ID = ?"
        sblob = pd.read_sql_query(spectrum_query, con, params=[spectrum_id])
        if sblob.empty:
            return None, None

        return get_spectra_from_xml(sblob.iloc[0]["Spectrum"])


def get_spectrum_by_id(con: sqlite3.Connection, spectrum_id: int):
    spectrum_query = "SELECT Spectrum FROM MassSpectrumItems WHERE ID = ?"
    sblob = pd.read_sql_query(spectrum_query, con, params=[int(spectrum_id)])
    if sblob.empty:
        return None, None
    return get_spectra_from_xml(sblob.iloc[0]["Spectrum"])


def get_best_scan_ms2_with_consolidated_ion_id(cid, cdresult_file):
    """Return compound-level best MS2 together with its linked associated feature ID.

    This prevents the audit/MGF FEATURE_ID from pointing to a preferred molecular
    associated feature when the MS2 spectrum was actually recovered only through
    the compound-level fallback. In that case, the FEATURE_ID should refer to the
    ion/feature linked to the recovered MS2 spectrum, when the CD SQLite schema
    exposes that linkage.
    """
    query = """
        SELECT
            ion.ID AS associated_feature_id,
            MassSpectrumInfoItems.ID AS spectrum_info_id
        FROM ConsolidatedUnknownCompoundItemsConsolidatedUnknownCompoundIonItems m
        JOIN ConsolidatedUnknownCompoundIonItems ion
          ON ion.ID = m.ConsolidatedUnknownCompoundIonItemsID
        JOIN ConsolidatedUnknownCompoundIonItemsBestHitIonInstanceItems ion_bhi
          ON ion_bhi.ConsolidatedUnknownCompoundIonItemsID = ion.ID
        JOIN BestHitIonInstanceItemsMassSpectrumInfoItems bhi_msi
          ON bhi_msi.BestHitIonInstanceItemsWorkflowID = ion_bhi.BestHitIonInstanceItemsWorkflowID
         AND bhi_msi.BestHitIonInstanceItemsID = ion_bhi.BestHitIonInstanceItemsID
        JOIN MassSpectrumInfoItems
          ON MassSpectrumInfoItems.WorkflowID = bhi_msi.MassSpectrumInfoItemsWorkflowID
         AND MassSpectrumInfoItems.ID = bhi_msi.MassSpectrumInfoItemsID
        WHERE m.ConsolidatedUnknownCompoundItemsID = ?
          AND MassSpectrumInfoItems.MSOrder = 2
        ORDER BY MassSpectrumInfoItems.ID
    """
    try:
        with sqlite3.connect(cdresult_file) as con:
            qres = pd.read_sql_query(query, con, params=[int(cid)])
            if not qres.empty:
                spectrum_id = int(qres.iloc[0]["spectrum_info_id"])
                associated_feature_id = safe_int(qres.iloc[0]["associated_feature_id"], "")
                ms2_df, iso_df = get_spectrum_by_id(con, spectrum_id)
                return ms2_df, iso_df, associated_feature_id
    except Exception:
        pass

    # Fallback when the linked associated feature ID cannot be recovered from
    # the SQLite relationships; a true feature ID cannot be guaranteed here.
    ms2_df, iso_df = get_best_scan_ms2(cid, cdresult_file)
    return ms2_df, iso_df, ""


def get_associated_features_for_compound(cid, cdresult_file) -> pd.DataFrame:
    """Get Features/Ion rows associated with one CD Compound Group from SQLite.

    This reads the same information that appears in the lower Features table of
    Compound Discoverer, including adduct/ion, feature m/z and RT. It does not
    require the exported Features table to contain a parent Compound ID.
    """
    query = """
        SELECT
            m.ConsolidatedUnknownCompoundItemsID AS compound_id,
            ion.ID AS associated_feature_id,
            ion.IonDescription AS associated_reference_ion,
            ion.Charge AS associated_charge,
            ion.MolecularWeight AS associated_molecular_weight,
            ion.Mass AS associated_mz,
            ion.RetentionTime AS associated_rt_min,
            ion.MaxArea AS associated_max_area,
            ion.Area AS associated_area,
            ion.IsDirectIon AS associated_is_direct_ion,
            ion.IsFragmentIon AS associated_is_fragment_ion,
            ion.MSnStatus AS associated_msn_status
        FROM ConsolidatedUnknownCompoundItemsConsolidatedUnknownCompoundIonItems m
        JOIN ConsolidatedUnknownCompoundIonItems ion
          ON ion.ID = m.ConsolidatedUnknownCompoundIonItemsID
        WHERE m.ConsolidatedUnknownCompoundItemsID = ?
    """
    with sqlite3.connect(cdresult_file) as con:
        return pd.read_sql_query(query, con, params=[int(cid)])


def get_associated_feature_details_by_id(cdresult_file, associated_feature_id) -> dict:
    """Return m/z, RT and ion label for a true CD associated Feature/Ion ID.

    These values are used only for audit consistency: when Relations displays
    feature_a/feature_b as true feature IDs, detail, delta_rt_min and delta_mz
    must be calculated from those same feature rows, not from the parent CD
    compound-group rows.
    """
    fid = safe_int(associated_feature_id, None)
    if fid is None or not cdresult_file or not os.path.exists(cdresult_file):
        return {}
    query = """
        SELECT
            ID AS actual_feature_id,
            IonDescription AS actual_feature_reference_ion,
            MolecularWeight AS actual_feature_calc_mw,
            Mass AS actual_feature_mz,
            RetentionTime AS actual_feature_rt_min,
            MaxArea AS actual_feature_max_area,
            Area AS actual_feature_area
        FROM ConsolidatedUnknownCompoundIonItems
        WHERE ID = ?
        LIMIT 1
    """
    try:
        with sqlite3.connect(cdresult_file) as con:
            df = pd.read_sql_query(query, con, params=[int(fid)])
            if df.empty:
                return {}
            r = df.iloc[0]
            return {
                "actual_feature_reference_ion": r.get("actual_feature_reference_ion", ""),
                "actual_feature_calc_mw": safe_float(r.get("actual_feature_calc_mw"), None),
                "actual_feature_mz": safe_float(r.get("actual_feature_mz"), None),
                "actual_feature_rt_min": safe_float(r.get("actual_feature_rt_min"), None),
                "actual_feature_max_area": safe_float(r.get("actual_feature_max_area"), None),
                "actual_feature_area": safe_float(r.get("actual_feature_area"), None),
            }
    except Exception:
        return {}


def find_actual_associated_feature_id_for_compound(cid, cdresult_file, reference_ion: str = "", precursor_mz=None, rt_min=None):
    """Return the most appropriate CD associated Feature/Ion ID for audit and MGF.

    Preference order:
      1) associated feature with matching ion label, m/z and RT;
      2) associated feature with matching m/z and RT;
      3) associated feature with matching m/z;
      4) first associated feature available.

    This prevents the audit FEATURE_ID from being empty when the script did not
    switch to a preferred [M+H]+/[M-H]- feature.
    """
    try:
        features = get_associated_features_for_compound(cid, cdresult_file)
    except Exception:
        return ""
    if features is None or features.empty or "associated_feature_id" not in features.columns:
        return ""

    work = features.copy()
    target_mz = safe_float(precursor_mz, None)
    target_rt = safe_float(rt_min, None)
    target_ion = canonical_ion_label(reference_ion) if reference_ion else ""

    work["_mz"] = work.get("associated_mz", pd.Series(index=work.index, dtype=object)).map(lambda x: safe_float(x, None))
    work["_rt"] = work.get("associated_rt_min", pd.Series(index=work.index, dtype=object)).map(lambda x: safe_float(x, None))
    work["_ion"] = work.get("associated_reference_ion", pd.Series(index=work.index, dtype=object)).map(canonical_ion_label)

    def mz_match(v):
        if target_mz is None or v is None:
            return False
        try:
            return within_ppm(float(v), float(target_mz), 10.0)
        except Exception:
            return False

    def rt_match(v):
        if target_rt is None or v is None:
            return False
        try:
            return abs(float(v) - float(target_rt)) <= 0.05
        except Exception:
            return False

    work["_mz_match"] = work["_mz"].map(mz_match)
    work["_rt_match"] = work["_rt"].map(rt_match)
    work["_ion_match"] = work["_ion"].eq(target_ion) if target_ion else False
    work["_area_rank"] = pd.to_numeric(work.get("associated_max_area", 0), errors="coerce").fillna(0)

    for mask in [
        work["_ion_match"] & work["_mz_match"] & work["_rt_match"],
        work["_mz_match"] & work["_rt_match"],
        work["_mz_match"],
    ]:
        cand = work.loc[mask].copy()
        if not cand.empty:
            cand = cand.sort_values("_area_rank", ascending=False)
            return cand.iloc[0].get("associated_feature_id", "")

    work = work.sort_values("_area_rank", ascending=False)
    return work.iloc[0].get("associated_feature_id", "")


# ---------------------------------------------------------------------
# Mass-error helper used for feature-ID matching
# ---------------------------------------------------------------------


def ppm_error(obs: float, theo: float) -> float:
    if theo == 0:
        return 999999.0
    return (obs - theo) / theo * 1e6


def within_ppm(obs: float, theo: float, ppm: float) -> bool:
    return abs(ppm_error(obs, theo)) <= float(ppm)


# ---------------------------------------------------------------------
# Study Information metadata helpers
# ---------------------------------------------------------------------


def find_study_information_table(table_paths: List[str]) -> Tuple[pd.DataFrame, str]:
    """Find the exported Compound Discoverer Study Information table.

    The table is recognized mainly by the presence of a File Name-like column.
    All columns, except File Name, are converted to metadata ATTRIBUTE_* columns.
    """
    best_df = None
    best_path = ""
    best_score = -1

    for p in table_paths:
        if not p or not os.path.exists(p):
            continue
        try:
            df = read_table_auto(p)
        except Exception:
            continue

        file_col = first_existing_col(df, [
            "File Name", "Filename", "FileName", "Raw File", "Raw File Name",
            "Sample File", "Sample Filename", "Data File", "Data File Name"
        ])
        if file_col is None:
            continue

        cols_norm = {norm(c) for c in df.columns}
        score = 10
        for expected in ["sampletype", "samplename", "sampleid", "group", "batch", "injectiontype"]:
            if expected in cols_norm:
                score += 2
        # Penalize a Compounds-like table if it somehow has a File Name column too.
        if {"rtinmin", "mz", "referenceion"}.issubset(cols_norm):
            score -= 5

        if score > best_score:
            best_df = df
            best_path = p
            best_score = score

    if best_df is None:
        raise RuntimeError(
            "Could not find the exported CD 'Study Information' table in NODEARGS. "
            "In the Scripting Node requested tables, add: Study Information: File Name "
            "and the metadata columns you want to export."
        )
    return best_df, best_path


def metadata_key(value: str) -> str:
    """Normalize a filename for matching quant table sample names to Study Information."""
    if value is None or pd.isna(value):
        return ""
    text = str(value).strip().replace("\\", "/").split("/")[-1]
    text = clean_sample_filename(text)
    return text.lower()


def cd_column_to_metadata_attribute_column(col: str) -> str:
    """Convert CD Study Information column names to metadata column names."""
    clean = re.sub(r"[^A-Za-z0-9]+", " ", str(col).strip())
    parts = [p for p in clean.split() if p]
    if not parts:
        return "ATTRIBUTE_Metadata"
    return "ATTRIBUTE_" + "".join(p[:1].upper() + p[1:] for p in parts)


def make_unique_columns(cols: List[str]) -> List[str]:
    """Ensure unique column names while preserving order."""
    seen = {}
    out = []
    for c in cols:
        if c not in seen:
            seen[c] = 1
            out.append(c)
        else:
            seen[c] += 1
            out.append(f"{c}_{seen[c]}")
    return out


# ---------------------------------------------------------------------
# Output writers
# ---------------------------------------------------------------------


def get_present_filenames_for_feature(row, sample_cols: List[str], sample_filenames: List[str], threshold: float = 0.0) -> str:
    """Return raw filenames where a feature is present, separated by semicolon.

    Presence is inferred from the CD area columns retained for the quant table.
    A filename is included when the corresponding area is greater than threshold.
    """
    present = []
    for col, fname in zip(sample_cols, sample_filenames):
        value = safe_float(row.get(col, 0), 0.0)
        if value is not None and value > float(threshold):
            present.append(fname)

    unique_present = []
    seen = set()
    for fname in present:
        if fname not in seen:
            unique_present.append(fname)
            seen.add(fname)

    return ";".join(unique_present)


def write_mgf(
    results_df: pd.DataFrame,
    output_mgf_path: Path,
    sample_cols: Optional[List[str]] = None,
    sample_filenames: Optional[List[str]] = None,
    min_ms2_peaks: int = 1,
) -> int:
    if sample_cols is None:
        sample_cols = []
    if sample_filenames is None:
        sample_filenames = []

    n_written = 0
    with open(output_mgf_path, "w", encoding="utf-8") as mgf:
        for _, row in results_df.iterrows():
            mz_values = row["MS2_mz_list"]
            int_values = row["MS2_intensity_list"]
            if not isinstance(mz_values, list) or not isinstance(int_values, list):
                continue
            if len(mz_values) < min_ms2_peaks or len(int_values) < min_ms2_peaks:
                continue

            row_id = int(row["feature_id"])
            actual_feature_id = safe_int(row.get("actual_feature_id", ""), None)
            if actual_feature_id is None:
                actual_feature_id = safe_int(row.get("selected_associated_feature_id", ""), None)
            if actual_feature_id is None:
                actual_feature_id = safe_int(row.get("Compounds ID", ""), row_id)
            precursor_mz = float(row["Precursor_mz"])
            rt_min = float(row["RT_min"])
            rt_seconds = rt_min * 60.0
            ion_type, _, polarity, mgf_charge = parse_reference_ion(row.get("Reference Ion", ""))
            title = f"ROW_{row_id}_FEATURE_{actual_feature_id}_CID_{row['Compounds ID']}_mz{precursor_mz:.6f}_RT{rt_min:.4f}"
            filenames = get_present_filenames_for_feature(row, sample_cols, sample_filenames, threshold=0.0)

            mgf.write("BEGIN IONS\n")
            mgf.write(f"SCANS={row_id}\n")
            mgf.write(f"FEATURE_ID={actual_feature_id}\n")
            mgf.write(f"CID={row['Compounds ID']}\n")
            mgf.write(f"TITLE={title}\n")
            mgf.write(f"FILENAME={filenames}\n")
            mgf.write(f"PEPMASS={precursor_mz:.8f}\n")
            mgf.write("MSLEVEL=2\n")
            mgf.write(f"CHARGE={mgf_charge}\n")
            mgf.write(f"RTINSECONDS={rt_seconds:.4f}\n")
            mgf.write(f"RTINMINUTES={rt_min:.6f}\n")
            mgf.write(f"ADDUCT={ion_type}\n")
            mgf.write(f"IONMODE={polarity}\n")

            for mz, inten in zip(mz_values, int_values):
                mgf.write(f"{float(mz):.8f} {float(inten):.6f}\n")
            mgf.write("END IONS\n\n")
            n_written += 1
    return n_written


def write_quant_table(
    results_df: pd.DataFrame,
    output_quant_path: Path,
    sample_cols: List[str],
    sample_filenames: List[str],
) -> pd.DataFrame:
    rows = []
    for _, row in results_df.iterrows():
        feature_id = int(row["feature_id"])
        actual_feature_id = safe_int(row.get("actual_feature_id", ""), None)
        if actual_feature_id is None:
            actual_feature_id = safe_int(row.get("selected_associated_feature_id", ""), None)
        if actual_feature_id is None:
            actual_feature_id = safe_int(row.get("Compounds ID", ""), feature_id)
        ion_type, _, polarity, _ = parse_reference_ion(row.get("Reference Ion", ""))

        out = {
            "row ID": feature_id,
            "row m/z": float(row["Precursor_mz"]),
            "row retention time": float(row["RT_min"]),
            "correlation group ID": feature_id,
            "annotation network number": feature_id,
            "best ion": ion_type,
            "auto MS2 verify": int(row.get("has_ms2", 0)),
            "identified by n=": 0,
            "partners": "",
            "neutral M mass": "",
            "compound_id": row["Compounds ID"],
            "feature_id": actual_feature_id,
            "reference_ion": row.get("Reference Ion", ""),
            "polarity": polarity,
            "n_ms2_fragments": int(row.get("n_ms2_fragments", 0)),
        }

        if sample_cols:
            for col, fname in zip(sample_cols, sample_filenames):
                out[f"{fname} Peak area"] = safe_float(row.get(col, 0), 0.0)
        else:
            out["CD_export.raw Peak area"] = 1.0

        rows.append(out)

    quant_df = pd.DataFrame(rows)
    quant_df.to_csv(output_quant_path, index=False)
    return quant_df


def write_metadata(
    output_metadata_path: Path,
    sample_filenames: List[str],
    study_info_df: pd.DataFrame,
) -> pd.DataFrame:
    """Write metadata using CD Study Information.

    Rules:
      - CD 'File Name' becomes MGF 'filename'.
      - Every other Study Information column becomes ATTRIBUTE_<CleanColumnName>.
      - Only samples retained in the quant table are written, in quant table order.
    """
    if not sample_filenames:
        sample_filenames = ["CD_export.raw"]

    file_col = first_existing_col(study_info_df, [
        "File Name", "Filename", "FileName", "Raw File", "Raw File Name",
        "Sample File", "Sample Filename", "Data File", "Data File Name"
    ])
    if file_col is None:
        raise RuntimeError(
            "The Study Information table was found, but it has no 'File Name' column. "
            "Export at least: Study Information: File Name."
        )

    attr_source_cols = [c for c in study_info_df.columns if c != file_col]
    attr_cols = make_unique_columns([cd_column_to_metadata_attribute_column(c) for c in attr_source_cols])

    study_by_file = {}
    for _, row in study_info_df.iterrows():
        key = metadata_key(row.get(file_col, ""))
        if key and key not in study_by_file:
            study_by_file[key] = row

    rows = []
    missing = []
    for fname in sample_filenames:
        key = metadata_key(fname)
        matched = study_by_file.get(key)
        out = {"filename": fname}
        for source_col, attr_col in zip(attr_source_cols, attr_cols):
            out[attr_col] = matched.get(source_col, "") if matched is not None else ""
        if matched is None:
            missing.append(fname)
        rows.append(out)

    metadata_df = pd.DataFrame(rows)
    metadata_df.to_csv(output_metadata_path, sep="\t", index=False)

    metadata_df.attrs["study_info_rows"] = int(len(study_info_df))
    metadata_df.attrs["study_info_attribute_columns"] = int(len(attr_cols))
    metadata_df.attrs["metadata_unmatched_filenames"] = missing
    return metadata_df


def compute_area_for_audit(row, area_max_col: Optional[str] = None) -> float:
    """Return the CD Area Max value for the audit workbook.

    The audit column 'area_max' must reflect Compound Discoverer's Area (Max.)
    value, not the sum of sample areas. The value is first read from the
    selected/actual associated feature MaxArea from SQLite when available;
    otherwise it falls back to the exported Compounds table Area Max column.
    """
    value = safe_float(row.get("_audit_area_max"), None)
    if value is not None:
        return float(value)
    if area_max_col:
        value = safe_float(row.get(area_max_col), None)
        if value is not None:
            return float(value)
    return 0.0


def compute_calc_mw_for_audit(row, calc_mw_col: Optional[str] = None):
    """Return calculated molecular weight for the audit workbook.

    Prefer the MolecularWeight of the actual CD associated feature from the
    .cdResult SQLite database. If unavailable, fall back to an exported
    Compounds table Calc. MW-like column. Blank is returned if neither exists.
    """
    value = safe_float(row.get("_audit_calc_mw"), None)
    if value is not None:
        return float(value)
    if calc_mw_col:
        value = safe_float(row.get(calc_mw_col), None)
        if value is not None:
            return float(value)
    return ""


def write_unresolved_audit(
    results_df: pd.DataFrame,
    selected_df: pd.DataFrame,
    blank_removed_df: pd.DataFrame,
    output_audit_path: Path,
    sample_cols: List[str],
    nonblank_sample_cols: List[str],
    blank_sample_cols: List[str],
    sample_filenames: List[str],
    blank_sample_filenames: List[str],
    area_max_col: Optional[str],
    calc_mw_col: Optional[str],
    metadata_df: pd.DataFrame,
    study_info_path: str,
    errors: List[str],
) -> None:
    """Write the audit workbook for the unresolved export.

    This branch does not perform MS2-purity filtering, representative-ion switching,
    or same-RT ion-redundancy resolution. Export requires a recoverable MS/MS spectrum
    and passage of the sample/blank ratio rule. All CD Compounds-table entries are
    retained in the audit, including rows excluded from MGF export.

    Legacy audit labels are preserved for backward-compatible output.
    """
    selected_original_ids = set(selected_df["Compounds ID"].astype(str).tolist()) if not selected_df.empty else set()
    blank_removed_original_ids = set(blank_removed_df["Compounds ID"].astype(str).tolist()) if blank_removed_df is not None and not blank_removed_df.empty else set()

    mgf_row_map = {}
    if not selected_df.empty:
        for _, r in selected_df.iterrows():
            mgf_row_map[str(r.get("Compounds ID", ""))] = r.get("feature_id", "")

    feature_rows = []
    for audit_idx, (_, row) in enumerate(results_df.iterrows(), start=1):
        original_cid = str(row.get("Compounds ID", ""))
        has_ms2 = int(row.get("n_ms2_fragments", 0)) > 0
        selected = original_cid in selected_original_ids
        blank_removed = original_cid in blank_removed_original_ids

        if selected:
            selection_reason = "selected_MS2_compound_not_present_in_blank"
            removal_category = "retained_selected_for_mgf"
            role = "selected_for_mgf_export"
        elif blank_removed:
            selection_reason = "removed_MS2_compound_present_in_blank"
            removal_category = "not_exported_present_in_blank"
            role = "removed_blank_present"
        else:
            selection_reason = "audit_reference_no_ms2_not_exported_to_mgf"
            removal_category = "not_exported_no_ms2"
            role = "no_ms2_not_exported"

        labels = []
        labels.append("has_ms2" if has_ms2 else "no_ms2")
        labels.append("selected_for_mgf" if selected else "not_selected_for_mgf")
        if blank_removed:
            labels.append("blank_present")
        labels.append("no_feature_selection_applied")

        feature_rows.append({
            "compound_id": audit_idx,
            "feature_id": row.get("actual_feature_id", ""),
            "row_id": int(mgf_row_map.get(original_cid)) if selected and safe_int(mgf_row_map.get(original_cid)) is not None else "",
            "rt_min": safe_float(row.get("RT_min"), ""),
            "mz": safe_float(row.get("Precursor_mz"), ""),
            "calc_mw": compute_calc_mw_for_audit(row, calc_mw_col),
            "area_max": compute_area_for_audit(row, area_max_col),
            "has_ms2": "TRUE" if has_ms2 else "FALSE",
            "selected_for_mgf": "TRUE" if selected else "FALSE",
            "selection_reason": selection_reason,
            "removal_category": removal_category,
            "resolver_feature_role": role,
            "labels": "; ".join(labels),
            "n_ms2_fragments": int(row.get("n_ms2_fragments", 0)),
            "ms2_purity_percent": safe_float(row.get("_ms2_purity_pct"), "") if has_ms2 else "",
            "original_reference_ion": row.get("Original Reference Ion", row.get("Reference Ion", "")),
            "selected_reference_ion": row.get("Reference Ion", ""),
        })

    feature_labels_df = pd.DataFrame(feature_rows)
    removed_rows_df = feature_labels_df.loc[feature_labels_df["selected_for_mgf"] != "TRUE"].copy()

    relations_df = pd.DataFrame(columns=[
        "row_id", "feature_a", "feature_b", "selected_feature_id", "relation_type", "direction",
        "rt_a_min", "rt_b_min", "mz_a", "mz_b", "ion_a", "ion_b",
        "calc_mw_a", "calc_mw_b", "delta_calc_mw", "delta_rt_min", "delta_mz"
    ])

    resolved_rows = []
    for _, r in feature_labels_df.loc[feature_labels_df["selected_for_mgf"] == "TRUE"].iterrows():
        resolved_rows.append({
            "compound_id": r["compound_id"],
            "n_features": 1,
            "selected_feature_id": r["feature_id"],
            "row_id": r["row_id"],
            "selected_rt_min": r["rt_min"],
            "selected_mz": r["mz"],
            "selected_calc_mw": r["calc_mw"],
            "selected_area_max": r["area_max"],
            "selected_ion": r["selected_reference_ion"],
            "feature_ids": r["feature_id"],
        })
    resolved_compounds_df = pd.DataFrame(resolved_rows, columns=[
        "compound_id", "n_features", "selected_feature_id", "row_id",
        "selected_rt_min", "selected_mz", "selected_calc_mw", "selected_area_max",
        "selected_ion", "feature_ids"
    ])

    summary_df = pd.DataFrame([
        {"Parameter": "audit_created", "Value": datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
        {"Parameter": "total_cd_compounds_read", "Value": int(len(results_df))},
        {"Parameter": "compounds_with_ms2", "Value": int((results_df["n_ms2_fragments"].astype(int) > 0).sum())},
        {"Parameter": "compounds_without_ms2", "Value": int((results_df["n_ms2_fragments"].astype(int) == 0).sum())},
        {"Parameter": "compounds_removed_present_in_blank", "Value": int(len(blank_removed_df)) if blank_removed_df is not None else 0},
        {"Parameter": "compounds_exported_to_mgf", "Value": int(len(selected_df))},
        {"Parameter": "sample_area_columns_detected", "Value": int(len(sample_cols))},
        {"Parameter": "nonblank_sample_columns_in_quant", "Value": int(len(nonblank_sample_cols))},
        {"Parameter": "blank_sample_columns_removed_from_quant", "Value": int(len(blank_sample_cols))},
        {"Parameter": "blank_samples_detected", "Value": ", ".join(blank_sample_filenames) if blank_sample_filenames else "none"},
        {"Parameter": "all_sample_filenames_detected", "Value": ", ".join(sample_filenames) if sample_filenames else "none"},
        {"Parameter": "metadata_rows", "Value": int(len(metadata_df))},
        {"Parameter": "study_information_table", "Value": study_info_path},
        {"Parameter": "study_information_rows", "Value": metadata_df.attrs.get("study_info_rows", "")},
        {"Parameter": "study_information_attribute_columns", "Value": metadata_df.attrs.get("study_info_attribute_columns", "")},
        {"Parameter": "metadata_unmatched_filenames", "Value": "; ".join(metadata_df.attrs.get("metadata_unmatched_filenames", [])) or "none"},
        {"Parameter": "warnings_or_errors_recorded", "Value": int(len(errors))},
        # Legacy values below are retained intentionally so public-release outputs
        # remain identical to those generated by the analysis script.
        {"Parameter": "export_mode", "Value": "non_cleaned_compounds_table_export_ms2_and_blank_filtered"},
        {"Parameter": "selection_rule", "Value": "only compounds with recoverable MS2 and not present in blank are exported; no feature selection, no purity filtering, no same-RT resolving, no molecular-ion preference switching"},
        {"Parameter": "blank_filtering_rule", "Value": "CD-like ratio rule: max_blank_area > 0 and max_sample_area / max_blank_area <= 5 excludes the compound from MGF and quant table"},
        {"Parameter": "relations_rule", "Value": "not applied in non-cleaned export"},
    ])
    if errors:
        err_df = pd.DataFrame({"Parameter": [f"warning_{i+1}" for i in range(min(len(errors), 200))], "Value": errors[:200]})
        summary_df = pd.concat([summary_df, err_df], ignore_index=True)

    try:
        with pd.ExcelWriter(output_audit_path, engine="openpyxl") as writer:
            feature_labels_df.to_excel(writer, sheet_name="Feature labels", index=False)
            removed_rows_df.to_excel(writer, sheet_name="Removed rows", index=False)
            relations_df.to_excel(writer, sheet_name="Relations", index=False)
            resolved_compounds_df.to_excel(writer, sheet_name="Resolved compounds", index=False)
            summary_df.to_excel(writer, sheet_name="Summary", index=False)

            wb = writer.book
            for ws in wb.worksheets:
                ws.freeze_panes = "A2"
                for cell in ws[1]:
                    cell.style = "Headline 4"
                for column_cells in ws.columns:
                    max_len = max(len(str(c.value)) if c.value is not None else 0 for c in column_cells)
                    ws.column_dimensions[column_cells[0].column_letter].width = min(max(max_len + 2, 10), 42)
    except ImportError as exc:
        raise RuntimeError(
            "Writing the audit .xlsx file requires openpyxl. "
            "Install it in the Python environment used by the CD Scripting Node: python -m pip install openpyxl"
        ) from exc


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------


def main() -> int:
    try:
        node_args, cdresult_file, table_paths = load_node_args()
        if not cdresult_file or not os.path.exists(cdresult_file):
            raise RuntimeError(f"Could not find .cdResult file from NODEARGS: {cdresult_file}")

        result_name = Path(cdresult_file).stem or "cd_result"
        outdir = Path(cdresult_file).parent / f"{result_name}_export"
        outdir.mkdir(parents=True, exist_ok=True)

        cd_input, cd_table_path = find_compounds_table(table_paths)
        study_info_df, study_info_path = find_study_information_table(table_paths)

        required = detect_required_columns(cd_input)
        area_max_col = required.get("area_max")
        calc_mw_col = required.get("calc_mw")
        purity_col = detect_ms2_purity_column(cd_input)
        sample_cols = detect_sample_area_columns(cd_input, required)
        sample_filenames = [clean_sample_filename(c) for c in sample_cols]

        # Unresolved export: blank columns are removed from quant/metadata, and
        # MS2-bearing entries are filtered using the max-sample/max-blank ratio rule.
        # Runtime labels remain unchanged for backward-compatible output.
        nonblank_sample_cols, nonblank_sample_filenames, blank_sample_cols, blank_sample_filenames = split_blank_and_nonblank_samples(
            sample_cols, sample_filenames
        )
        output_sample_cols = nonblank_sample_cols
        output_sample_filenames = nonblank_sample_filenames

        results = []
        errors = []

        for i, row in cd_input.iterrows():
            cid = safe_int(row[required["compound_id"]])
            rt_min = safe_float(row[required["rt_min"]])
            precursor_mz = safe_float(row[required["mz"]])
            ref_ion = row[required["reference_ion"]] if required.get("reference_ion") else "[Unknown]"

            if cid is None or rt_min is None or precursor_mz is None:
                errors.append(f"Skipped row {i}: missing compound ID, RT, or m/z")
                continue

            actual_feature_id = ""
            actual_feature_id_source = ""

            try:
                ms2_df, iso_df, linked_feature_id = get_best_scan_ms2_with_consolidated_ion_id(cid, cdresult_file)
                if linked_feature_id not in ["", None]:
                    actual_feature_id = linked_feature_id
                    actual_feature_id_source = "compound_best_ms2_linked_associated_feature"
                elif ms2_df is not None and not ms2_df.empty:
                    actual_feature_id = cid
                    actual_feature_id_source = "compound_best_ms2_feature_id_unavailable"
            except Exception as e:
                errors.append(f"Compound ID {cid}: MS2 extraction failed: {e}")
                ms2_df = pd.DataFrame(columns=["mz", "intensity"])
                iso_df = pd.DataFrame(columns=["mz", "intensity"])

            if ms2_df is None:
                ms2_df = pd.DataFrame(columns=["mz", "intensity"])
            if iso_df is None:
                iso_df = pd.DataFrame(columns=["mz", "intensity"])

            # For no-MS2 audit rows only, keep a best-effort feature ID for traceability.
            if actual_feature_id in ["", None]:
                actual_feature_id = find_actual_associated_feature_id_for_compound(
                    cid, cdresult_file, ref_ion, precursor_mz=precursor_mz, rt_min=rt_min
                )
                actual_feature_id_source = "matched_associated_feature_no_direct_ms2" if actual_feature_id not in ["", None] else ""
            if actual_feature_id in ["", None]:
                actual_feature_id = cid
                actual_feature_id_source = "fallback_cd_compound_id_no_associated_feature_found"

            actual_feature_details = get_associated_feature_details_by_id(cdresult_file, actual_feature_id)
            actual_feature_reference_ion = actual_feature_details.get("actual_feature_reference_ion", ref_ion)
            actual_feature_mz = actual_feature_details.get("actual_feature_mz", precursor_mz)
            actual_feature_rt_min = actual_feature_details.get("actual_feature_rt_min", rt_min)
            actual_feature_area_max = actual_feature_details.get("actual_feature_max_area", None)
            actual_feature_calc_mw = actual_feature_details.get("actual_feature_calc_mw", None)
            exported_area_max = safe_float(row.get(area_max_col), None) if area_max_col else None
            exported_calc_mw = safe_float(row.get(calc_mw_col), None) if calc_mw_col else None
            audit_area_max = actual_feature_area_max if actual_feature_area_max is not None else exported_area_max
            audit_calc_mw = actual_feature_calc_mw if actual_feature_calc_mw is not None else exported_calc_mw

            has_ms2_flag = int(ms2_df is not None and not ms2_df.empty)
            n_ms2_fragments = int(len(ms2_df) if ms2_df is not None else 0)

            # Purity is retrieved only as annotation, not as a selection/filtering rule.
            if has_ms2_flag and cid is not None:
                if purity_col and purity_col in cd_input.columns:
                    ms2_purity_pct = normalize_purity_percent(row.get(purity_col), None)
                else:
                    ms2_purity_pct, _ms2_purity_source = find_sqlite_ms2_purity_for_compound(cid, cdresult_file)
            else:
                ms2_purity_pct = None

            record = row.to_dict()
            record.update({
                "feature_id": cid,  # temporary; overwritten with sequential row IDs for exported MS2 rows
                "Compounds ID": cid,
                "RT_min": rt_min,
                "Precursor_mz": precursor_mz,
                "Reference Ion": ref_ion,
                "Original Reference Ion": ref_ion,
                "selected_reference_source": "compound_table_reference_ion_no_cleaning",
                "selected_associated_feature_id": "",
                "actual_feature_id": actual_feature_id,
                "actual_feature_id_source": actual_feature_id_source,
                "actual_feature_reference_ion": actual_feature_reference_ion,
                "actual_feature_calc_mw": actual_feature_calc_mw,
                "actual_feature_mz": actual_feature_mz,
                "actual_feature_rt_min": actual_feature_rt_min,
                "_audit_area_max": audit_area_max,
                "_audit_calc_mw": audit_calc_mw,
                "MS2_mz_list": ms2_df["mz"].tolist() if not ms2_df.empty else [],
                "MS2_intensity_list": ms2_df["intensity"].tolist() if not ms2_df.empty else [],
                "Isotopic_mz_list": iso_df["mz"].tolist() if not iso_df.empty else [],
                "Isotopic_intensity_list": iso_df["intensity"].tolist() if not iso_df.empty else [],
                "has_ms2": has_ms2_flag,
                "n_ms2_fragments": n_ms2_fragments,
                "_ms2_purity_pct": ms2_purity_pct,
                "_ms2_purity_source": "",
            })
            results.append(record)

        results_df = pd.DataFrame(results)
        if results_df.empty:
            raise RuntimeError("No compounds were exported. Check the Compounds table columns and diagnostics.")

        ms2_results_before_blank_df = results_df[results_df["n_ms2_fragments"].astype(int) > 0].copy().reset_index(drop=True)
        selected_df, blank_removed_df = filter_out_blank_present_features(
            ms2_results_before_blank_df, nonblank_sample_cols, blank_sample_cols, ratio_threshold=5.0
        )
        selected_df = selected_df.reset_index(drop=True)
        blank_removed_df = blank_removed_df.reset_index(drop=True)
        selected_df["feature_id"] = range(1, len(selected_df) + 1)

        output_mgf = outdir / f"{result_name}_spectra.mgf"
        output_quant = outdir / f"{result_name}_quant.csv"
        output_metadata = outdir / f"{result_name}_metadata.tsv"
        output_audit = outdir / f"{result_name}_audit.xlsx"

        n_mgf = write_mgf(
            selected_df,
            output_mgf,
            sample_cols=output_sample_cols,
            sample_filenames=output_sample_filenames,
            min_ms2_peaks=1,
        )
        quant_df = write_quant_table(selected_df, output_quant, output_sample_cols, output_sample_filenames)
        metadata_df = write_metadata(output_metadata, output_sample_filenames, study_info_df)
        write_unresolved_audit(
            results_df=results_df,
            selected_df=selected_df,
            blank_removed_df=blank_removed_df,
            output_audit_path=output_audit,
            sample_cols=sample_cols,
            nonblank_sample_cols=nonblank_sample_cols,
            blank_sample_cols=blank_sample_cols,
            sample_filenames=sample_filenames,
            blank_sample_filenames=blank_sample_filenames,
            area_max_col=area_max_col,
            calc_mw_col=calc_mw_col,
            metadata_df=metadata_df,
            study_info_path=study_info_path,
            errors=errors,
        )

        report_lines = [
            "CD to MGF export completed",
            f"Input CD table: {cd_table_path}",
            f"Study Information table: {study_info_path}",
            f"CD result file: {cdresult_file}",
            f"Output folder: {outdir}",
            f"Compounds read from CD table: {len(results_df)}",
            f"Compounds with MS2 before blank filtering: {len(ms2_results_before_blank_df)}",
            f"MS2 compounds removed because present in blank: {len(blank_removed_df)}",
            f"Compounds with MS2 exported after blank filtering: {len(selected_df)}",
            f"Compounds without MS2 not exported: {len(results_df) - len(ms2_results_before_blank_df)}",
            f"MS2 spectra written to MGF after blank filtering: {n_mgf}",
            f"Quant table rows: {len(quant_df)}",
            f"Metadata rows: {len(metadata_df)}",
            f"Sample columns detected before blank removal: {len(sample_cols)}",
            f"Blank sample columns removed from quant table: {len(blank_sample_cols)}",
            f"Non-blank sample columns retained in quant table: {len(output_sample_cols)}",
            f"Blank samples detected: {', '.join(blank_sample_filenames) if blank_sample_filenames else 'none'}",
            "",
            "Final output files:",
            f"- {output_mgf}",
            f"- {output_quant}",
            f"- {output_metadata}",
            f"- {output_audit}",
            "",
            "Notes:",
            "- Non-cleaned export with blank removal: no feature selection, no purity filtering, no same-RT resolving, and no molecular-ion preference switching are applied.",
            "- Export requirements: a recoverable MS/MS spectrum and CD-like blank rule passed: max_blank_area = 0 or max_sample_area / max_blank_area > 5.",
            "- Blank columns are removed from quant and metadata outputs.",
            "- MGF SCANS matches quant table row ID; MGF FEATURE_ID is the linked CD associated feature ID when available.",
        ]
        if errors:
            report_lines.extend(["", "Warnings/errors:"] + errors[:200])

        print("\n".join(report_lines))
        return 0

    except Exception as e:
        err_dir = Path.cwd() / "cd_mgf_export_error"
        err_dir.mkdir(exist_ok=True)
        with open(err_dir / "error.txt", "w", encoding="utf-8") as f:
            f.write(str(e) + "\n\n")
            f.write(traceback.format_exc())
        print("ERROR:", e)
        print(traceback.format_exc())
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
