# -*- coding: utf-8 -*-
"""
cd_ion_resolver_export.py

Compound Discoverer Scripting Node helper.

Goal
----
Export ion-redundancy-resolved Compound Discoverer results directly to MGF/feature-table-friendly files:

    1) <result_name>_spectra.mgf
    2) <result_name>_quant.csv
    3) <result_name>_metadata.tsv
    4) <result_name>_audit.xlsx

This script is designed to be run inside a Compound Discoverer Scripting Node:

    python cd_ion_resolver_export.py %NODEARGS%

What it does
------------
- Reads the Scripting Node JSON argument file.
- Reads the exported CD Compounds table.
- Opens the .cdResult SQLite file.
- Retrieves the best MS/MS spectrum associated with each compound group.
- Writes an MGF where SCANS matches the quantification table row ID; FEATURE_ID reports the associated CD feature/ion ID when available.
- Writes MGF and quantification files using only entries with recoverable MS/MS spectra.
- Collapses same-RT related ions to one representative feature before MGF export.
- Writes metadata from the exported CD Study Information table.
- Writes only the four final output files listed above.

Important
---------
For a good MGF export workflow, request/export the upper Compounds table from CD with at least:
    Compounds ID, mz, RT in min, Reference Ion
and preferably the sample area columns.

If your CD table uses different names, this script tries common variants.
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import sys
import tempfile
import traceback
import zipfile
from datetime import datetime
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Iterable, List, Optional, Tuple

import pandas as pd


# ---------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(s).strip().lower())


def safe_float(value, default=None):
    try:
        if value is None or pd.isna(value):
            return default
        txt = str(value).strip().replace(",", ".")
        if txt == "":
            return default
        return float(txt)
    except Exception:
        return default


def safe_int(value, default=None):
    try:
        f = safe_float(value, None)
        if f is None:
            return default
        return int(f)
    except Exception:
        return default


def first_existing_col(df: pd.DataFrame, candidates: Iterable[str]) -> Optional[str]:
    cmap = {norm(c): c for c in df.columns}
    for c in candidates:
        if norm(c) in cmap:
            return cmap[norm(c)]
    return None


def read_table_auto(path: str) -> pd.DataFrame:
    try:
        return pd.read_csv(path, sep="\t", dtype=str, keep_default_na=False)
    except Exception:
        return pd.read_csv(path, sep=None, engine="python", dtype=str, keep_default_na=False)


def qident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def get_tables(con: sqlite3.Connection) -> List[str]:
    q = "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    return pd.read_sql_query(q, con)["name"].tolist()


def get_cols(con: sqlite3.Connection, table: str) -> List[str]:
    return pd.read_sql_query(f'PRAGMA table_info({qident(table)})', con)["name"].tolist()


# ---------------------------------------------------------------------
# Node argument and CD table handling
# ---------------------------------------------------------------------


def load_node_args() -> Tuple[dict, str, List[str]]:
    if len(sys.argv) < 2:
        raise RuntimeError("Expected %NODEARGS% JSON path as first argument.")

    node_args_file = sys.argv[1]
    with open(node_args_file, "r", encoding="utf-8-sig") as f:
        node_args = json.load(f)

    cdresult_file = node_args.get("ResultFilePath") or node_args.get("ResultFile") or ""
    if not cdresult_file:
        for v in node_args.values():
            if isinstance(v, str) and v.lower().endswith(".cdresult"):
                cdresult_file = v
                break

    table_paths = []
    tables = node_args.get("Tables", [])
    if isinstance(tables, list):
        for t in tables:
            if isinstance(t, dict):
                p = t.get("DataFile") or t.get("File") or t.get("Path") or t.get("FilePath")
                if p:
                    table_paths.append(p)
            elif isinstance(t, str):
                table_paths.append(t)

    return node_args, cdresult_file, table_paths


def find_compounds_table(table_paths: List[str]) -> Tuple[pd.DataFrame, str]:
    best_df = None
    best_path = ""
    best_score = -1

    for p in table_paths:
        if not p or not os.path.exists(p):
            continue
        try:
            df = read_table_auto(p)
        except Exception:
            continue

        cols_norm = {norm(c) for c in df.columns}
        score = 0
        for expected in ["compoundsid", "compoundid", "id", "rtinmin", "mz", "referenceion"]:
            if expected in cols_norm:
                score += 1
        if any("compound" in norm(c) for c in df.columns):
            score += 1

        if score > best_score:
            best_df = df
            best_path = p
            best_score = score

    if best_df is None:
        raise RuntimeError("Could not find an exported CD Compounds table in NODEARGS.")
    return best_df, best_path


def detect_required_columns(df: pd.DataFrame) -> dict:
    cols = {
        "compound_id": first_existing_col(df, ["Compounds ID", "Compound ID", "ID"]),
        "mz": first_existing_col(df, ["mz", "m/z", "Mass", "Mass to Charge", "Precursor m/z"]),
        "rt_min": first_existing_col(df, ["RT in min", "RT [min]", "Retention Time", "RetentionTime", "Apex RT"]),
        "reference_ion": first_existing_col(df, ["Reference Ion", "Ion", "Ion Type", "Adduct", "Best Ion"]),
        "area_max": first_existing_col(df, [
            "Area (Max.)", "Area Max", "Area Max.", "AreaMax", "Max Area", "MaxArea",
            "Maximum Area", "Area Maximum"
        ]),
        "calc_mw": first_existing_col(df, [
            "Calc. MW", "Calc MW", "Calculated MW", "Calculated Molecular Weight",
            "Molecular Weight", "MW", "Monoisotopic Mass", "Neutral Mass"
        ]),
        "formula": first_existing_col(df, ["Molecular Formula", "Formula"]),
        "name": first_existing_col(df, ["Name", "Compound Name", "Preferred Name", "Annotation"]),
    }
    missing = [k for k in ["compound_id", "mz", "rt_min"] if cols[k] is None]
    if missing:
        raise RuntimeError(
            "Missing required columns in CD table: {}. Available columns: {}".format(
                missing, list(df.columns)
            )
        )
    return cols


def detect_ms2_purity_column(df: pd.DataFrame) -> Optional[str]:
    """Detect a Compound Discoverer MS2 purity column, if it was exported.

    The exact CD display name can vary. This function intentionally does not
    make the column mandatory, because CD may refuse some requested column names
    before the Python script starts. If the column is present, the purity filter
    is applied; if it is absent, the script continues and records this in audit.
    """
    return first_existing_col(df, [
        "MS2 Purity [%]", "MS2 Purity", "MS2Purity", "MS2 Purity Percent",
        "MS/MS Purity", "MSMS Purity", "MSn Purity", "MSN Purity",
        "Isolation Purity", "Precursor Purity", "Purity [%]", "Purity"
    ])


def normalize_purity_percent(value, default=None):
    """Return MS2 purity as percent. Accepts either 0-100 or 0-1 values."""
    v = safe_float(value, default)
    if v is None or pd.isna(v):
        return default
    if 0.0 < float(v) <= 1.0:
        return float(v) * 100.0
    return float(v)


def filter_by_ms2_purity(df: pd.DataFrame, purity_col: Optional[str], threshold: float = 60.0) -> Tuple[pd.DataFrame, pd.DataFrame, bool]:
    """Keep only rows with MS2/Isolation Purity >= threshold.

    The values may come either from an exported CD column or from the .cdResult
    SQLite database. This is intentionally strict: rows with missing purity are
    removed because they do not demonstrate MS2/Isolation Purity >= threshold.
    """
    work = df.copy()
    if purity_col and purity_col in work.columns:
        work["_ms2_purity_pct"] = work[purity_col].map(lambda x: normalize_purity_percent(x, pd.NA))
        work["_ms2_purity_source"] = work["_ms2_purity_source"].where(
            work.get("_ms2_purity_source", pd.Series(index=work.index, dtype=object)).astype(str).ne("none"),
            f"exported:{purity_col}"
        ) if "_ms2_purity_source" in work.columns else f"exported:{purity_col}"
    elif "_ms2_purity_pct" not in work.columns:
        work["_ms2_purity_pct"] = pd.NA
    if "_ms2_purity_source" not in work.columns:
        work["_ms2_purity_source"] = "none"

    purity = pd.to_numeric(work["_ms2_purity_pct"], errors="coerce")
    keep_mask = purity >= float(threshold)

    # Explicitly mark missing values, so the audit distinguishes true low purity
    # from unavailable purity information. Both are excluded from MGF/quant.
    missing_mask = purity.isna()
    work.loc[missing_mask, "_ms2_purity_source"] = "missing_not_demonstrable"

    kept = work.loc[keep_mask].copy()
    removed = work.loc[~keep_mask].copy()
    return kept, removed, True


def get_ms2_spectrum_info_ids_for_compound(cid, con: sqlite3.Connection) -> List[int]:
    """Return MassSpectrumInfoItems IDs for MS2 spectra linked to a CD compound ID.

    This mirrors the same Compound Discoverer linkage used by get_best_scan_ms2().
    It is used only to retrieve spectrum-level fields such as MS2 purity when the
    Scripting Node does not export the visible Compounds table column.
    """
    if cid is None:
        return []
    query = """
        SELECT MassSpectrumInfoItems.ID
        FROM ConsolidatedUnknownCompoundItems,
             ConsolidatedUnknownCompoundItemsBestHitIonInstanceItems,
             BestHitIonInstanceItems,
             BestHitIonInstanceItemsMassSpectrumInfoItems,
             MassSpectrumInfoItems
        WHERE ConsolidatedUnknownCompoundItems.ID =
              ConsolidatedUnknownCompoundItemsBestHitIonInstanceItems.ConsolidatedUnknownCompoundItemsID
          AND BestHitIonInstanceItems.ID =
              ConsolidatedUnknownCompoundItemsBestHitIonInstanceItems.BestHitIonInstanceItemsID
          AND BestHitIonInstanceItemsMassSpectrumInfoItems.BestHitIonInstanceItemsID =
              BestHitIonInstanceItems.ID
          AND BestHitIonInstanceItemsMassSpectrumInfoItems.MassSpectrumInfoItemsID =
              MassSpectrumInfoItems.ID
          AND ConsolidatedUnknownCompoundItems.ID = ?
          AND MassSpectrumInfoItems.MSOrder = 2
        ORDER BY MassSpectrumInfoItems.ID
    """
    try:
        qres = pd.read_sql_query(query, con, params=[int(cid)])
        if qres.empty or "ID" not in qres.columns:
            return []
        return [int(x) for x in qres["ID"].dropna().tolist()]
    except Exception:
        return []


def get_purity_candidate_columns(cols: List[str]) -> List[str]:
    """Return possible SQLite columns carrying MS2/isolation purity.

    CD display columns can be computed from spectrum-level fields and may not use
    the exact name 'MS2 Purity'. This deliberately accepts any column containing
    'purity' and a few isolation/precursor variants.
    """
    out = []
    for c in cols:
        n = norm(c)
        if "purity" in n:
            out.append(c)
        elif "isolation" in n and any(tok in n for tok in ["percent", "pct", "ratio", "score"]):
            out.append(c)
        elif "precursor" in n and any(tok in n for tok in ["pur", "isolation"]):
            out.append(c)
    return out


def find_sqlite_ms2_purity_for_compound(cid, cdresult_file):
    """Try to retrieve CD MS2 Purity [%] directly from the .cdResult SQLite file.

    Strategy:
      1) Find the MS2 MassSpectrumInfoItems linked to the compound and search
         spectrum-level purity columns there. This is the most likely source of
         the visible 'MS2 Purity [%]' value in the Compounds table.
      2) Fall back to compound/ion/best-hit tables using CD compound ID columns.
    """
    if cid is None or not cdresult_file or not os.path.exists(cdresult_file):
        return None, "none"

    try:
        with sqlite3.connect(cdresult_file) as con:
            # First, look at the MassSpectrumInfoItems rows linked to this compound.
            spectrum_info_ids = get_ms2_spectrum_info_ids_for_compound(cid, con)
            for table in ["MassSpectrumInfoItems", "MassSpectrumItems"]:
                if table not in get_tables(con):
                    continue
                try:
                    cols = get_cols(con, table)
                except Exception:
                    continue
                purity_cols = get_purity_candidate_columns(cols)
                if not purity_cols or "ID" not in cols:
                    continue
                for spectrum_id in spectrum_info_ids:
                    for sqlite_purity_col in purity_cols:
                        try:
                            q = f"SELECT {qident(sqlite_purity_col)} AS purity_value FROM {qident(table)} WHERE {qident('ID')} = ? LIMIT 1"
                            df = pd.read_sql_query(q, con, params=[int(spectrum_id)])
                            if df.empty:
                                continue
                            value = normalize_purity_percent(df.iloc[0]["purity_value"], None)
                            if value is not None and not pd.isna(value):
                                return value, f"sqlite:{table}.{sqlite_purity_col};MassSpectrumInfoItemsID={spectrum_id}"
                        except Exception:
                            continue

            # Fallback: search compound/ion/best-hit tables directly by compound-like IDs.
            preferred_tables = [
                "ConsolidatedUnknownCompoundItems",
                "UnknownCompoundItems",
                "CompoundItems",
                "BestHitIonInstanceItems",
                "ConsolidatedUnknownCompoundIonItems",
                "MassSpectrumInfoItems",
                "MassSpectrumItems",
            ]
            compound_id_norms = {
                "id",
                "consolidatedunknowncompounditemsid",
                "unknowncompounditemsid",
                "compounditemsid",
                "compoundid",
                "compoundsid",
            }
            table_names = get_tables(con)
            ordered_tables = [t for t in preferred_tables if t in table_names] + [t for t in table_names if t not in preferred_tables]
            for table in ordered_tables:
                try:
                    cols = get_cols(con, table)
                except Exception:
                    continue
                if not cols:
                    continue

                purity_cols = get_purity_candidate_columns(cols)
                if not purity_cols:
                    continue

                id_cols = [c for c in cols if norm(c) in compound_id_norms]
                if table in {"ConsolidatedUnknownCompoundItems", "UnknownCompoundItems", "CompoundItems"} and "ID" in cols:
                    id_cols = ["ID"] + [c for c in id_cols if c != "ID"]

                for id_col in id_cols:
                    for sqlite_purity_col in purity_cols:
                        try:
                            q = f"SELECT {qident(sqlite_purity_col)} AS purity_value FROM {qident(table)} WHERE {qident(id_col)} = ? LIMIT 1"
                            df = pd.read_sql_query(q, con, params=[int(cid)])
                            if df.empty:
                                continue
                            value = normalize_purity_percent(df.iloc[0]["purity_value"], None)
                            if value is not None and not pd.isna(value):
                                return value, f"sqlite:{table}.{sqlite_purity_col}"
                        except Exception:
                            continue
    except Exception:
        return None, "none"

    return None, "none"


def detect_sample_area_columns(df: pd.DataFrame, required_cols: dict) -> List[str]:
    non_sample = {c for c in required_cols.values() if c}
    sample_cols = []

    patterns = [
        "area", "abundance", "height", "intensity", "normalizedarea", "peakarea"
    ]

    for col in df.columns:
        n = norm(col)
        if col in non_sample:
            continue
        if any(p in n for p in patterns):
            # Exclude obvious non-sample summary columns if possible.
            if any(x in n for x in ["max", "mean", "median", "rsd", "cv", "blankflag"]):
                continue
            sample_cols.append(col)

    # If no sample columns are detected, the quant table still benefits from a dummy column
    # so that the quant table remains structurally valid.
    return sample_cols


def is_blank_sample_name(name: str) -> bool:
    """Return True for blank/solvent/control blank sample names or CD area columns."""
    n = norm(name)
    blank_tokens = ["blank", "bianco", "blanc", "blk", "solventblank", "methodblank"]
    return any(tok in n for tok in blank_tokens)


def split_blank_and_nonblank_samples(sample_cols: List[str], sample_filenames: List[str]) -> Tuple[List[str], List[str], List[str], List[str]]:
    """Split sample area columns into blank and non-blank columns.

    Returns:
        nonblank_cols, nonblank_filenames, blank_cols, blank_filenames
    """
    nonblank_cols = []
    nonblank_filenames = []
    blank_cols = []
    blank_filenames = []

    for col, fname in zip(sample_cols, sample_filenames):
        if is_blank_sample_name(col) or is_blank_sample_name(fname):
            blank_cols.append(col)
            blank_filenames.append(fname)
        else:
            nonblank_cols.append(col)
            nonblank_filenames.append(fname)

    return nonblank_cols, nonblank_filenames, blank_cols, blank_filenames


def filter_out_blank_present_features(
    df: pd.DataFrame,
    blank_cols: List[str],
    nonblank_cols: Optional[List[str]] = None,
    ratio_threshold: float = 5.0,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Remove background features using a CD-like sample/blank ratio rule.

    A feature is removed only when it is present in at least one blank and the
    strongest non-blank sample signal is not sufficiently higher than the
    strongest blank signal:

        max_blank_area > 0 AND max_sample_area / max_blank_area <= ratio_threshold

    With the default ratio_threshold=5.0 this mirrors the CD Mark Background
    concept "Max Sample/Blank = 5" more closely than the older strict rule that
    removed every feature with any positive blank area.
    """
    if df.empty or not blank_cols:
        return df.copy(), df.iloc[0:0].copy()

    work = df.copy()
    if nonblank_cols is None:
        nonblank_cols = []

    blank_cols_existing = [c for c in blank_cols if c in work.columns]
    nonblank_cols_existing = [c for c in nonblank_cols if c in work.columns]

    if not blank_cols_existing:
        return work, work.iloc[0:0].copy()

    blank_area_frame = work[blank_cols_existing].apply(pd.to_numeric, errors="coerce").fillna(0.0)
    max_blank_area = blank_area_frame.max(axis=1)

    if nonblank_cols_existing:
        sample_area_frame = work[nonblank_cols_existing].apply(pd.to_numeric, errors="coerce").fillna(0.0)
        max_sample_area = sample_area_frame.max(axis=1)
    else:
        # No non-blank signal is available to demonstrate sample/blank > threshold.
        max_sample_area = pd.Series(0.0, index=work.index)

    ratio = pd.Series(float("inf"), index=work.index)
    positive_blank = max_blank_area > 0.0
    ratio.loc[positive_blank] = max_sample_area.loc[positive_blank] / max_blank_area.loc[positive_blank]

    background = positive_blank & (ratio <= float(ratio_threshold))

    # Keep these as internal diagnostic columns. They are not written as audit
    # columns unless explicitly selected later.
    work["_max_blank_area_for_filter"] = max_blank_area
    work["_max_sample_area_for_filter"] = max_sample_area
    work["_sample_blank_ratio_for_filter"] = ratio

    kept = work.loc[~background].copy()
    removed = work.loc[background].copy()
    return kept, removed


def clean_sample_filename(col: str) -> str:
    """Convert a Compound Discoverer area column into a metadata filename.

    Examples:
        Area MIXACIDI_10UGMlraw F3      -> MIXACIDI_10UGMl.raw
        Area BLANK_20230327235046raw F4 -> BLANK_20230327235046.raw
        Sample1.raw Area                -> Sample1.raw
    """
    name = str(col).strip()
    name = re.sub(r"\s*\(.*?\)\s*", "", name)
    name = re.sub(r"^(Area|Height|Intensity|Abundance)(?:\s*:\s*|\s+)", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\s+(Area|Height|Intensity|Abundance)$", "", name, flags=re.IGNORECASE)
    name = re.sub(r"\s+F\d+(?:\.(?:raw|mzml|mzxml|cdf))?$", "", name, flags=re.IGNORECASE)
    name = name.replace("\\", "/").split("/")[-1].strip()

    # CD sometimes removes the dot before raw/mzML in exported area column names.
    name = re.sub(r"(?i)(?<!\.)raw$", ".raw", name)
    name = re.sub(r"(?i)mzml$", ".mzML", name)
    name = re.sub(r"(?i)mzxml$", ".mzXML", name)

    if not re.search(r"\.(raw|mzml|mzxml|cdf)$", name, flags=re.IGNORECASE):
        name = name + ".raw"
    return name


# ---------------------------------------------------------------------
# Ion/adduct parsing
# ---------------------------------------------------------------------


def parse_reference_ion(reference_ion):
    if reference_ion is None or pd.isna(reference_ion) or str(reference_ion).strip() == "":
        return "[Unknown]", 1, "+", "1+"

    ref = str(reference_ion).strip()
    ion_match = re.search(r"(\[.*?\][+-])", ref)
    ion_type = ion_match.group(1) if ion_match else ref

    polarity = "-" if ion_type.endswith("-") else "+"
    charge_abs = 1

    m1 = re.search(r"([+-])(\d+)$", ref)
    m2 = re.search(r"(\d+)([+-])$", ref)

    if m1:
        polarity = m1.group(1)
        charge_abs = int(m1.group(2))
    elif m2:
        charge_abs = int(m2.group(1))
        polarity = m2.group(2)
    else:
        if "+3H" in ref or "-3H" in ref:
            charge_abs = 3
        elif "+2H" in ref or "-2H" in ref:
            charge_abs = 2

    return ion_type, charge_abs, polarity, f"{charge_abs}{polarity}"


def canonical_ion_label(reference_ion: str) -> str:
    """Return the clean adduct label used for molecular-ion preference.

    Examples:
        [M+H]+1    -> [M+H]+
        [M-H]-1    -> [M-H]-
        [M+Na]+1   -> [M+Na]+
        [M+2H]+2   -> [M+2H]2+
        [M-2H]-2   -> [M-2H]2-

    Compound Discoverer can export doubly charged species in slightly different
    textual forms. This normalization keeps neutral-mass matching reliable for
    [M+H]+/[M+2H]2+ and [M-H]-/[M-2H]2- pairs.
    """
    ion_type, charge_abs, polarity, _ = parse_reference_ion(reference_ion)
    lab = str(ion_type).replace(" ", "").upper()

    # Normalize common CD forms such as [M+2H]+2 or [M-2H]-2.
    if charge_abs > 1 and lab.endswith("+") and "]" in lab:
        return lab[:-1] + f"{charge_abs}+"
    if charge_abs > 1 and lab.endswith("-") and "]" in lab:
        return lab[:-1] + f"{charge_abs}-"

    return lab


def reference_ion_was_reassigned(original_reference_ion: str, selected_reference_ion: str) -> bool:
    """Return True only when the resolver changed the ion-type assignment.

    The comparison is performed on canonicalized ion labels so that equivalent
    Compound Discoverer notations such as [M+H]+1 and [M+H]+ are not counted
    as a reassignment. Missing/unknown labels are not counted as reassigned.
    """
    original = canonical_ion_label(original_reference_ion)
    selected = canonical_ion_label(selected_reference_ion)
    if original in {"", "[UNKNOWN]"} or selected in {"", "[UNKNOWN]"}:
        return False
    return original != selected


def is_molecular_protonated_or_deprotonated(reference_ion: str) -> bool:
    lab = canonical_ion_label(reference_ion)
    return lab in {"[M+H]+", "[M-H]-"}


def molecular_ion_priority(candidate_ion: str, current_reference_ion: str) -> int:
    """Lower score is better. Prefer the mode-consistent molecular ion."""
    cand = canonical_ion_label(candidate_ion)
    _, _, current_pol, _ = parse_reference_ion(current_reference_ion)
    if current_pol == "-":
        order = {"[M-H]-": 0, "[M+H]+": 1}
    else:
        order = {"[M+H]+": 0, "[M-H]-": 1}
    return order.get(cand, 99)


# ---------------------------------------------------------------------
# MS/MS extraction from CD SQLite spectrum blobs
# ---------------------------------------------------------------------


def get_spectra_from_xml(zspec):
    if zspec is None:
        return pd.DataFrame(columns=["mz", "intensity"]), pd.DataFrame(columns=["mz", "intensity"])

    with tempfile.TemporaryDirectory() as tmpdir:
        zip_path = os.path.join(tmpdir, "spec.zip")
        with open(zip_path, "wb") as f:
            f.write(zspec)

        with zipfile.ZipFile(zip_path, "r") as z:
            names = z.namelist()
            if not names:
                return pd.DataFrame(columns=["mz", "intensity"]), pd.DataFrame(columns=["mz", "intensity"])
            z.extractall(tmpdir)
            xml_file = os.path.join(tmpdir, names[0])

        tree = ET.parse(xml_file)
        root = tree.getroot()

        ms2 = []
        for peak in root.findall(".//PeakCentroids/Peak"):
            mz = safe_float(peak.get("X"))
            intensity = safe_float(peak.get("Y"))
            if mz is not None and intensity is not None:
                ms2.append({"mz": mz, "intensity": intensity})

        isotope = []
        for peak in root.findall(".//IsotopeClusterPeakCentroids/Peak"):
            mz = safe_float(peak.get("X"))
            intensity = safe_float(peak.get("Y"))
            if mz is not None and intensity is not None:
                isotope.append({"mz": mz, "intensity": intensity})

        return (
            pd.DataFrame(ms2, columns=["mz", "intensity"]),
            pd.DataFrame(isotope, columns=["mz", "intensity"]),
        )


def get_best_scan_ms2(cid, cdresult_file):
    """Return MS2 and isotope DataFrames for one compound ID.

    The first query matches common CD 3.4/3.5 schemas. If it fails because
    a schema variant is different, the caller records diagnostics.
    """
    query = """
        SELECT MassSpectrumInfoItems.ID
        FROM ConsolidatedUnknownCompoundItems,
             ConsolidatedUnknownCompoundItemsBestHitIonInstanceItems,
             BestHitIonInstanceItems,
             BestHitIonInstanceItemsMassSpectrumInfoItems,
             MassSpectrumInfoItems
        WHERE ConsolidatedUnknownCompoundItems.ID =
              ConsolidatedUnknownCompoundItemsBestHitIonInstanceItems.ConsolidatedUnknownCompoundItemsID
          AND BestHitIonInstanceItems.ID =
              ConsolidatedUnknownCompoundItemsBestHitIonInstanceItems.BestHitIonInstanceItemsID
          AND BestHitIonInstanceItemsMassSpectrumInfoItems.BestHitIonInstanceItemsID =
              BestHitIonInstanceItems.ID
          AND BestHitIonInstanceItemsMassSpectrumInfoItems.MassSpectrumInfoItemsID =
              MassSpectrumInfoItems.ID
          AND ConsolidatedUnknownCompoundItems.ID = ?
          AND MassSpectrumInfoItems.MSOrder = 2
    """

    with sqlite3.connect(cdresult_file) as con:
        qres = pd.read_sql_query(query, con, params=[int(cid)])
        if qres.empty:
            return None, None

        spectrum_id = int(qres.iloc[0]["ID"])
        spectrum_query = "SELECT Spectrum FROM MassSpectrumItems WHERE ID = ?"
        sblob = pd.read_sql_query(spectrum_query, con, params=[spectrum_id])
        if sblob.empty:
            return None, None

        return get_spectra_from_xml(sblob.iloc[0]["Spectrum"])


def get_spectrum_by_id(con: sqlite3.Connection, spectrum_id: int):
    spectrum_query = "SELECT Spectrum FROM MassSpectrumItems WHERE ID = ?"
    sblob = pd.read_sql_query(spectrum_query, con, params=[int(spectrum_id)])
    if sblob.empty:
        return None, None
    return get_spectra_from_xml(sblob.iloc[0]["Spectrum"])


def get_ms2_for_consolidated_ion(ion_item_id, cdresult_file):
    """Return the MS2 spectrum linked to one ConsolidatedUnknownCompoundIonItems row.

    This is used when we switch the compound reference ion to [M+H]+ or [M-H]-.
    If the selected molecular-ion feature has its own MS2, this keeps PEPMASS,
    adduct and fragment spectrum internally consistent. If no MS2 is linked to
    that ion, the caller can fall back to the compound-level best MS2.
    """
    query = """
        SELECT MassSpectrumInfoItems.ID
        FROM ConsolidatedUnknownCompoundIonItemsBestHitIonInstanceItems
        JOIN BestHitIonInstanceItemsMassSpectrumInfoItems
          ON BestHitIonInstanceItemsMassSpectrumInfoItems.BestHitIonInstanceItemsWorkflowID =
             ConsolidatedUnknownCompoundIonItemsBestHitIonInstanceItems.BestHitIonInstanceItemsWorkflowID
         AND BestHitIonInstanceItemsMassSpectrumInfoItems.BestHitIonInstanceItemsID =
             ConsolidatedUnknownCompoundIonItemsBestHitIonInstanceItems.BestHitIonInstanceItemsID
        JOIN MassSpectrumInfoItems
          ON MassSpectrumInfoItems.WorkflowID = BestHitIonInstanceItemsMassSpectrumInfoItems.MassSpectrumInfoItemsWorkflowID
         AND MassSpectrumInfoItems.ID = BestHitIonInstanceItemsMassSpectrumInfoItems.MassSpectrumInfoItemsID
        WHERE ConsolidatedUnknownCompoundIonItemsBestHitIonInstanceItems.ConsolidatedUnknownCompoundIonItemsID = ?
          AND MassSpectrumInfoItems.MSOrder = 2
        ORDER BY MassSpectrumInfoItems.ID
    """
    with sqlite3.connect(cdresult_file) as con:
        qres = pd.read_sql_query(query, con, params=[int(ion_item_id)])
        if qres.empty:
            return None, None
        return get_spectrum_by_id(con, int(qres.iloc[0]["ID"]))


def get_best_scan_ms2_with_consolidated_ion_id(cid, cdresult_file):
    """Return compound-level best MS2 together with its linked associated feature ID.

    This prevents the audit/MGF FEATURE_ID from pointing to a preferred molecular
    associated feature when the MS2 spectrum was actually recovered only through
    the compound-level fallback. In that case, the FEATURE_ID should refer to the
    ion/feature linked to the recovered MS2 spectrum, when the CD SQLite schema
    exposes that linkage.
    """
    query = """
        SELECT
            ion.ID AS associated_feature_id,
            MassSpectrumInfoItems.ID AS spectrum_info_id
        FROM ConsolidatedUnknownCompoundItemsConsolidatedUnknownCompoundIonItems m
        JOIN ConsolidatedUnknownCompoundIonItems ion
          ON ion.ID = m.ConsolidatedUnknownCompoundIonItemsID
        JOIN ConsolidatedUnknownCompoundIonItemsBestHitIonInstanceItems ion_bhi
          ON ion_bhi.ConsolidatedUnknownCompoundIonItemsID = ion.ID
        JOIN BestHitIonInstanceItemsMassSpectrumInfoItems bhi_msi
          ON bhi_msi.BestHitIonInstanceItemsWorkflowID = ion_bhi.BestHitIonInstanceItemsWorkflowID
         AND bhi_msi.BestHitIonInstanceItemsID = ion_bhi.BestHitIonInstanceItemsID
        JOIN MassSpectrumInfoItems
          ON MassSpectrumInfoItems.WorkflowID = bhi_msi.MassSpectrumInfoItemsWorkflowID
         AND MassSpectrumInfoItems.ID = bhi_msi.MassSpectrumInfoItemsID
        WHERE m.ConsolidatedUnknownCompoundItemsID = ?
          AND MassSpectrumInfoItems.MSOrder = 2
        ORDER BY MassSpectrumInfoItems.ID
    """
    try:
        with sqlite3.connect(cdresult_file) as con:
            qres = pd.read_sql_query(query, con, params=[int(cid)])
            if not qres.empty:
                spectrum_id = int(qres.iloc[0]["spectrum_info_id"])
                associated_feature_id = safe_int(qres.iloc[0]["associated_feature_id"], "")
                ms2_df, iso_df = get_spectrum_by_id(con, spectrum_id)
                return ms2_df, iso_df, associated_feature_id
    except Exception:
        pass

    # Fallback when the associated feature ID cannot be recovered from the
    # compound-to-spectrum linkage. In this path, a true feature ID cannot be guaranteed.
    ms2_df, iso_df = get_best_scan_ms2(cid, cdresult_file)
    return ms2_df, iso_df, ""


def get_associated_features_for_compound(cid, cdresult_file) -> pd.DataFrame:
    """Get Features/Ion rows associated with one CD Compound Group from SQLite.

    This reads the same information that appears in the lower Features table of
    Compound Discoverer, including adduct/ion, feature m/z and RT. It does not
    require the exported Features table to contain a parent Compound ID.
    """
    query = """
        SELECT
            m.ConsolidatedUnknownCompoundItemsID AS compound_id,
            ion.ID AS associated_feature_id,
            ion.IonDescription AS associated_reference_ion,
            ion.Charge AS associated_charge,
            ion.MolecularWeight AS associated_molecular_weight,
            ion.Mass AS associated_mz,
            ion.RetentionTime AS associated_rt_min,
            ion.MaxArea AS associated_max_area,
            ion.Area AS associated_area,
            ion.IsDirectIon AS associated_is_direct_ion,
            ion.IsFragmentIon AS associated_is_fragment_ion,
            ion.MSnStatus AS associated_msn_status
        FROM ConsolidatedUnknownCompoundItemsConsolidatedUnknownCompoundIonItems m
        JOIN ConsolidatedUnknownCompoundIonItems ion
          ON ion.ID = m.ConsolidatedUnknownCompoundIonItemsID
        WHERE m.ConsolidatedUnknownCompoundItemsID = ?
    """
    with sqlite3.connect(cdresult_file) as con:
        return pd.read_sql_query(query, con, params=[int(cid)])


def choose_preferred_reference_feature(cid, cdresult_file, current_reference_ion: str) -> Optional[dict]:
    """Choose the associated Feature/Ion to export to MGF, requiring direct MS2 first.

    Selection rule:
      1) Only associated features with a recoverable direct MS2 spectrum are considered.
      2) If [M+H]+ or [M-H]- has direct MS2, prefer the mode-consistent molecular ion.
      3) If no [M+H]+/[M-H]- feature has direct MS2, select the MS2-bearing adduct
         with the largest MaxArea.

    This prevents writing PEPMASS/ADDUCT for [M+H]+ while the actual recovered MS2
    was acquired on another adduct such as [M+Na]+.
    """
    features = get_associated_features_for_compound(cid, cdresult_file)
    if features.empty or "associated_reference_ion" not in features.columns:
        return None

    candidates = []
    for _, feature_row in features.iterrows():
        fid = feature_row.get("associated_feature_id", "")
        if fid in ["", None] or pd.isna(fid):
            continue
        try:
            ms2_df, iso_df = get_ms2_for_consolidated_ion(fid, cdresult_file)
        except Exception:
            ms2_df, iso_df = None, None
        if ms2_df is None or ms2_df.empty:
            continue
        rec = feature_row.to_dict()
        rec["_direct_ms2_df"] = ms2_df
        rec["_direct_iso_df"] = iso_df if iso_df is not None else pd.DataFrame(columns=["mz", "intensity"])
        rec["_canon"] = canonical_ion_label(rec.get("associated_reference_ion", ""))
        rec["_is_molecular"] = 1 if rec["_canon"] in {"[M+H]+", "[M-H]-"} else 0
        rec["_priority"] = molecular_ion_priority(rec.get("associated_reference_ion", ""), current_reference_ion)
        rec["_area_rank"] = safe_float(rec.get("associated_max_area"), 0.0) or 0.0
        candidates.append(rec)

    if not candidates:
        return None

    mol_candidates = [c for c in candidates if c.get("_is_molecular") == 1]
    if mol_candidates:
        # Prefer mode-consistent [M+H]+/[M-H]-, then largest area.
        mol_candidates = sorted(mol_candidates, key=lambda c: (-(99 - float(c.get("_priority", 99))), c.get("_area_rank", 0.0)), reverse=True)
        # The sorting above keeps high area important but priority can be clearer with a tuple below.
        mol_candidates = sorted(mol_candidates, key=lambda c: (float(c.get("_priority", 99)), -float(c.get("_area_rank", 0.0))))
        best = mol_candidates[0]
        best["selected_reference_source"] = "associated_feature_molecular_ion_with_direct_ms2"
        return best

    # No molecular ion with direct MS2: keep the MS2-bearing adduct with largest area.
    candidates = sorted(candidates, key=lambda c: float(c.get("_area_rank", 0.0)), reverse=True)
    best = candidates[0]
    best["selected_reference_source"] = "associated_adduct_with_direct_ms2_largest_area"
    return best


def get_associated_feature_details_by_id(cdresult_file, associated_feature_id) -> dict:
    """Return m/z, RT and ion label for a true CD associated Feature/Ion ID.

    These values are used only for audit consistency: when Relations displays
    feature_a/feature_b as true feature IDs, detail, delta_rt_min and delta_mz
    must be calculated from those same feature rows, not from the parent CD
    compound-group rows.
    """
    fid = safe_int(associated_feature_id, None)
    if fid is None or not cdresult_file or not os.path.exists(cdresult_file):
        return {}
    query = """
        SELECT
            ID AS actual_feature_id,
            IonDescription AS actual_feature_reference_ion,
            MolecularWeight AS actual_feature_calc_mw,
            Mass AS actual_feature_mz,
            RetentionTime AS actual_feature_rt_min,
            MaxArea AS actual_feature_max_area,
            Area AS actual_feature_area
        FROM ConsolidatedUnknownCompoundIonItems
        WHERE ID = ?
        LIMIT 1
    """
    try:
        with sqlite3.connect(cdresult_file) as con:
            df = pd.read_sql_query(query, con, params=[int(fid)])
            if df.empty:
                return {}
            r = df.iloc[0]
            return {
                "actual_feature_reference_ion": r.get("actual_feature_reference_ion", ""),
                "actual_feature_calc_mw": safe_float(r.get("actual_feature_calc_mw"), None),
                "actual_feature_mz": safe_float(r.get("actual_feature_mz"), None),
                "actual_feature_rt_min": safe_float(r.get("actual_feature_rt_min"), None),
                "actual_feature_max_area": safe_float(r.get("actual_feature_max_area"), None),
                "actual_feature_area": safe_float(r.get("actual_feature_area"), None),
            }
    except Exception:
        return {}


def audit_relation_row_from_actual_features(row: pd.Series) -> pd.Series:
    """Return a copy of a resolver row using actual feature parameters for relation checks."""
    out = row.copy()
    actual_mz = safe_float(row.get("actual_feature_mz"), None)
    actual_rt = safe_float(row.get("actual_feature_rt_min"), None)
    actual_ion = row.get("actual_feature_reference_ion", "")
    if actual_mz is not None:
        out["Precursor_mz"] = actual_mz
    if actual_rt is not None:
        out["RT_min"] = actual_rt
    if actual_ion not in ["", None] and not pd.isna(actual_ion):
        out["Reference Ion"] = actual_ion
    return out

def find_actual_associated_feature_id_for_compound(cid, cdresult_file, reference_ion: str = "", precursor_mz=None, rt_min=None):
    """Return the most appropriate CD associated Feature/Ion ID for audit and MGF.

    Preference order:
      1) associated feature with matching ion label, m/z and RT;
      2) associated feature with matching m/z and RT;
      3) associated feature with matching m/z;
      4) first associated feature available.

    This prevents the audit FEATURE_ID from being empty when the script did not
    switch to a preferred [M+H]+/[M-H]- feature.
    """
    try:
        features = get_associated_features_for_compound(cid, cdresult_file)
    except Exception:
        return ""
    if features is None or features.empty or "associated_feature_id" not in features.columns:
        return ""

    work = features.copy()
    target_mz = safe_float(precursor_mz, None)
    target_rt = safe_float(rt_min, None)
    target_ion = canonical_ion_label(reference_ion) if reference_ion else ""

    work["_mz"] = work.get("associated_mz", pd.Series(index=work.index, dtype=object)).map(lambda x: safe_float(x, None))
    work["_rt"] = work.get("associated_rt_min", pd.Series(index=work.index, dtype=object)).map(lambda x: safe_float(x, None))
    work["_ion"] = work.get("associated_reference_ion", pd.Series(index=work.index, dtype=object)).map(canonical_ion_label)

    def mz_match(v):
        if target_mz is None or v is None:
            return False
        try:
            return within_ppm(float(v), float(target_mz), 10.0)
        except Exception:
            return False

    def rt_match(v):
        if target_rt is None or v is None:
            return False
        try:
            return abs(float(v) - float(target_rt)) <= 0.05
        except Exception:
            return False

    work["_mz_match"] = work["_mz"].map(mz_match)
    work["_rt_match"] = work["_rt"].map(rt_match)
    work["_ion_match"] = work["_ion"].eq(target_ion) if target_ion else False
    work["_area_rank"] = pd.to_numeric(work.get("associated_max_area", 0), errors="coerce").fillna(0)

    for mask in [
        work["_ion_match"] & work["_mz_match"] & work["_rt_match"],
        work["_mz_match"] & work["_rt_match"],
        work["_mz_match"],
    ]:
        cand = work.loc[mask].copy()
        if not cand.empty:
            cand = cand.sort_values("_area_rank", ascending=False)
            return cand.iloc[0].get("associated_feature_id", "")

    work = work.sort_values("_area_rank", ascending=False)
    return work.iloc[0].get("associated_feature_id", "")

# ---------------------------------------------------------------------
# RT/adduct/in-source grouping before MGF export
# ---------------------------------------------------------------------

PROTON = 1.007276466812
MASS_NA = 22.989218
MASS_K = 38.963158
MASS_NH4 = 18.033823
MASS_CL = 34.969402
MASS_FA = 46.005479       # formic acid / formate adduct mass difference vs [M-H]-
MASS_AC = 60.021129       # acetic acid / acetate adduct mass difference vs [M-H]-
MASS_ACN = 41.026549
MASS_H2O = 18.010565
MASS_CO2 = 43.989829
MASS_CH4O = 32.026215
MASS_CH2 = 14.015650

# Generic CH2-related mass-difference series. These labels describe observed
# absolute m/z differences and do not imply a specific reaction direction.
# The upper limit is finite to avoid very large, non-specific differences being
# used as automatic collapse criteria.
MAX_CH2_DIFFERENCE_MULTIPLE = 6

def ch2_mass_difference_label(n: int) -> str:
    if n == 1:
        return "CH2_mass_difference"
    return f"C{n}H{2*n}_mass_difference"

CH2_MULTIPLE_MASS_DIFFERENCES = [
    (ch2_mass_difference_label(n), MASS_CH2 * n)
    for n in range(1, MAX_CH2_DIFFERENCE_MULTIPLE + 1)
]

MASS_DIFFERENCE_RULES = [
    ("H2O_mass_difference", MASS_H2O),
    ("CO2_mass_difference", MASS_CO2),
    ("ACN_mass_difference", MASS_ACN),
    ("CH4O_mass_difference", MASS_CH4O),
] + CH2_MULTIPLE_MASS_DIFFERENCES

# Additional adduct sanity check independent of the CD Reference Ion assignment.
# This catches common cases where CD labels both ions as [M+H]+ although their
# observed m/z difference is typical of H/Na or H/K adduct pairs. These relations
# are only evaluated after the same-RT and same-raw checks in the resolver.
# We intentionally do not include H/NH4 here because its diagnostic delta is
# identical to the nominal NH3 neutral-loss mass difference and is therefore
# intrinsically ambiguous without independent ion/adduct evidence. H/ACN is
# likewise not inferred from delta alone because it overlaps ACN mass-difference logic.
OBSERVED_ADDUCT_DELTA_RULES = [
    ("adduct_compatible_delta_H_Na", MASS_NA - PROTON, "higher_is_secondary"),
    ("adduct_compatible_delta_H_K", MASS_K - PROTON, "higher_is_secondary"),
    ("adduct_compatible_delta_Na_K", MASS_K - MASS_NA, "both_secondary"),
]


def ppm_error(obs: float, theo: float) -> float:
    if theo == 0:
        return 999999.0
    return (obs - theo) / theo * 1e6


def within_ppm(obs: float, theo: float, ppm: float) -> bool:
    return abs(ppm_error(obs, theo)) <= float(ppm)


class UnionFind:
    def __init__(self, items):
        self.parent = {x: x for x in items}

    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a, b):
        ra = self.find(a)
        rb = self.find(b)
        if ra != rb:
            self.parent[rb] = ra


def adduct_neutral_mass(mz: float, ion_label: str) -> Optional[float]:
    """Return putative neutral mass from common CD/MZmine adduct labels.

    This is intentionally conservative and only used to group coeluting ions.
    Unsupported labels return None rather than forcing an assignment.
    """
    if mz is None:
        return None
    lab = canonical_ion_label(ion_label)
    if not lab or lab == "[UNKNOWN]":
        return None

    # Singly charged positive mode.
    if lab == "[M+H]+":
        return mz - PROTON
    if lab == "[M+NA]+":
        return mz - MASS_NA
    if lab == "[M+K]+":
        return mz - MASS_K
    if lab == "[M+NH4]+":
        return mz - MASS_NH4
    if lab in {"[M+ACN+H]+", "[M+CH3CN+H]+"}:
        return mz - MASS_ACN - PROTON

    # Doubly charged positive mode.
    # Some CD exports report the adduct as [M+2H]+ without keeping the charge
    # state in the adduct string; include that form so it is not missed.
    if lab in {"[M+2H]2+", "[M+2H]+2", "[M+2H]+"}:
        return mz * 2.0 - 2.0 * PROTON
    if lab in {"[M+ACN+2H]2+", "[M+ACN+2H]+2", "[M+CH3CN+2H]2+", "[M+CH3CN+2H]+2"}:
        return mz * 2.0 - MASS_ACN - 2.0 * PROTON

    # Singly charged negative mode.
    if lab == "[M-H]-":
        return mz + PROTON
    if lab == "[M+CL]-":
        return mz - MASS_CL
    if lab in {"[M+FA-H]-", "[M+HCOO]-", "[M+HCOOH-H]-"}:
        return mz - MASS_FA + PROTON
    if lab in {"[M+AC-H]-", "[M+CH3COO]-", "[M+CH3COOH-H]-"}:
        return mz - MASS_AC + PROTON

    # Doubly charged negative mode. Include [M-2H]- as a defensive CD-style form.
    if lab in {"[M-2H]2-", "[M-2H]-2", "[M-2H]-"}:
        return mz * 2.0 + 2.0 * PROTON

    # Dimers/multimers. These are secondary species; they can be linked to a monomer
    # but should not become the MGF representative when a monomeric alternative exists.
    if lab == "[2M+H]+":
        return (mz - PROTON) / 2.0
    if lab == "[2M+NA]+":
        return (mz - MASS_NA) / 2.0
    if lab == "[2M-H]-":
        return (mz + PROTON) / 2.0
    if lab == "[2M+CL]-":
        return (mz - MASS_CL) / 2.0

    return None


def is_secondary_ion_label(ion_label: str) -> bool:
    lab = canonical_ion_label(ion_label)
    secondary_tokens = [
        "2M", "2H", "ACN", "CH3CN", "NA", "K", "NH4", "CL", "FA", "HCOO", "AC", "CH3COO",
        "H2O", "NH3", "CO2"
    ]
    if lab in {"[M+H]+", "[M-H]-"}:
        return False
    return any(tok in lab for tok in secondary_tokens)


def has_fragment_match(child_mz: float, parent_ms2_mz: List[float], frag_ppm: float = 5.0) -> bool:
    if child_mz is None or not isinstance(parent_ms2_mz, list):
        return False
    for fmz in parent_ms2_mz:
        try:
            if within_ppm(float(fmz), float(child_mz), frag_ppm):
                return True
        except Exception:
            continue
    return False


def adduct_compatible_delta_relation(
    row_a: pd.Series,
    row_b: pd.Series,
    neutral_ppm: float = 10.0,
    delta_abs_tol_da: float = 0.002,
) -> Optional[str]:
    """Detect common adduct-pair m/z deltas even if CD adduct labels are wrong.

    This is a conservative correction layer, not a full adduct re-annotation.
    It only flags very diagnostic observed deltas such as [M+H]+/[M+Na]+
    and [M+H]+/[M+K]+. The same-RT and same-raw requirements are enforced
    by the calling resolver before this function is used.

    Important implementation detail: the tolerance is evaluated both as ppm on
    the delta and as an absolute m/z difference. Ppm on a small delta such as
    21.98194 Da can be too strict: a 0.0003 Da mass error is only sub-ppm on a
    400 Da ion, but about 14 ppm when calculated on the 21.98 Da delta itself.
    The absolute tolerance therefore catches real H/Na and H/K pairs that CD may
    have mislabeled, while the same-RT and same-raw gates keep the rule specific.
    """
    mz_a = safe_float(row_a.get("Precursor_mz"), None)
    mz_b = safe_float(row_b.get("Precursor_mz"), None)
    if mz_a is None or mz_b is None:
        return None
    dm = abs(float(mz_a) - float(mz_b))
    for name, mass, _role in OBSERVED_ADDUCT_DELTA_RULES:
        if within_ppm(dm, mass, neutral_ppm) or abs(dm - mass) <= float(delta_abs_tol_da):
            return name
    return None


def adduct_compatible_delta_secondary_flags(row_a: pd.Series, row_b: pd.Series, relation: str) -> Tuple[bool, bool]:
    """Return inferred secondary-adduct flags for a delta-based adduct relation.

    For H/Na and H/K, the higher-m/z feature is likely the secondary adduct and
    the lower-m/z feature is likely the molecular ion. For Na/K, both are
    secondary with respect to the underlying neutral.
    """
    mz_a = safe_float(row_a.get("Precursor_mz"), None)
    mz_b = safe_float(row_b.get("Precursor_mz"), None)
    if mz_a is None or mz_b is None:
        return False, False
    if relation in {"adduct_compatible_delta_H_Na", "adduct_compatible_delta_H_K"}:
        if mz_a > mz_b:
            return True, False
        if mz_b > mz_a:
            return False, True
    if relation == "adduct_compatible_delta_Na_K":
        return True, True
    return False, False


def ion_relation_label(row_a: pd.Series, row_b: pd.Series, neutral_ppm: float = 10.0, frag_ppm: float = 5.0) -> Optional[str]:
    """Return relation label for two coeluting rows, or None.

    Relations are evaluated in a fixed priority order:
    - same neutral mass from supported ion labels;
    - adduct-compatible observed m/z deltas;
    - predefined absolute mass-difference rules;
    - lower m/z matching a product ion in MS/MS of the higher-m/z feature.
    """
    mz_a = safe_float(row_a.get("Precursor_mz"), None)
    mz_b = safe_float(row_b.get("Precursor_mz"), None)
    if mz_a is None or mz_b is None:
        return None

    ion_a = row_a.get("Reference Ion", "")
    ion_b = row_b.get("Reference Ion", "")
    nm_a = adduct_neutral_mass(mz_a, ion_a)
    nm_b = adduct_neutral_mass(mz_b, ion_b)
    if nm_a is not None and nm_b is not None and within_ppm(nm_a, nm_b, neutral_ppm):
        return "adduct_or_multimer_same_neutral_mass"

    # If CD assigned the adduct label incorrectly, neutral-mass matching can fail.
    # Before evaluating generic mass-difference rules, check whether the observed m/z
    # delta itself is diagnostic of a common adduct pair such as H/Na or H/K.
    # The delta check uses both ppm and an absolute Da tolerance, because ppm on
    # a 21.98 Da Na-H delta can miss accurate Orbitrap pairs with only ~0.0003 Da
    # absolute error.
    observed_adduct_relation = adduct_compatible_delta_relation(row_a, row_b, neutral_ppm=neutral_ppm)
    if observed_adduct_relation:
        return observed_adduct_relation

    dm = abs(mz_a - mz_b)
    for name, mass in MASS_DIFFERENCE_RULES:
        if within_ppm(dm, mass, neutral_ppm):
            return name

    # MS2-child relation: the lower m/z matches a product ion of the higher-m/z feature.
    if mz_a > mz_b:
        if has_fragment_match(mz_b, row_a.get("MS2_mz_list", []), frag_ppm=frag_ppm):
            return "ms2_child_fragment_match"
    elif mz_b > mz_a:
        if has_fragment_match(mz_a, row_b.get("MS2_mz_list", []), frag_ppm=frag_ppm):
            return "ms2_child_fragment_match"

    return None


def representative_sort_key(row: pd.Series):
    """Sort key for selecting one MGF representative from a resolved compound group.

    Priority:
    1. [M+H]+/[M-H]- molecular ion;
    2. non-secondary monomer-like ion;
    3. secondary adduct/cluster/multimer;
    within each class, prefer higher m/z when all candidates have MS2.
    """
    ion = row.get("Reference Ion", "")
    is_mol = 1 if is_molecular_protonated_or_deprotonated(ion) else 0
    inferred_secondary = int(safe_float(row.get("_inferred_secondary_adduct_by_delta", 0), 0) or 0)
    is_secondary = 1 if (is_secondary_ion_label(ion) or inferred_secondary == 1) else 0
    mz = safe_float(row.get("Precursor_mz"), 0.0) or 0.0
    area = safe_float(row.get("_max_nonblank_area", 0.0), 0.0) or 0.0
    # Higher tuple is better. Delta-inferred secondary adducts are penalized so
    # that a likely [M+Na]+ or [M+K]+ does not win over the coeluting [M+H]+ just
    # because CD mislabeled both ions as [M+H]+.
    return (is_mol, 1 - is_secondary, mz, area)


def child_relation_parent_child_indices(row_a: pd.Series, row_b: pd.Series, frag_ppm: float = 5.0) -> Tuple[Optional[str], Optional[str]]:
    """Return which of two directly compared rows is parent/child for an MS2-child edge.

    The parent is the higher-m/z feature whose MS/MS contains the lower-m/z feature.
    Returned values are "a"/"b" labels, not row indices.
    """
    mz_a = safe_float(row_a.get("Precursor_mz"), None)
    mz_b = safe_float(row_b.get("Precursor_mz"), None)
    if mz_a is None or mz_b is None or mz_a == mz_b:
        return None, None
    if mz_a > mz_b and has_fragment_match(mz_b, row_a.get("MS2_mz_list", []), frag_ppm=frag_ppm):
        return "a", "b"
    if mz_b > mz_a and has_fragment_match(mz_a, row_b.get("MS2_mz_list", []), frag_ppm=frag_ppm):
        return "b", "a"
    return None, None


def present_raw_file_set(row: pd.Series, sample_cols: Optional[List[str]], sample_filenames: Optional[List[str]], threshold: float = 0.0) -> set:
    """Return raw files where the row has a positive area.

    This is used by the same-RT resolver so that adduct, transformation and
    MS2-child relations are accepted only between features observed in at least
    one same raw file/sample.
    """
    if not sample_cols or not sample_filenames:
        return set()
    present = set()
    for col, fname in zip(sample_cols, sample_filenames):
        value = safe_float(row.get(col, 0), 0.0)
        if value is not None and value > float(threshold):
            present.add(str(fname))
    return present


def shared_raw_files(row_a: pd.Series, row_b: pd.Series, sample_cols: Optional[List[str]], sample_filenames: Optional[List[str]], threshold: float = 0.0) -> List[str]:
    """Return sorted raw filenames shared by two rows.

    If sample columns are unavailable, no shared raw file is inferred: this keeps
    the resolver conservative and prevents grouping based only on coelution.
    """
    files_a = present_raw_file_set(row_a, sample_cols, sample_filenames, threshold=threshold)
    files_b = present_raw_file_set(row_b, sample_cols, sample_filenames, threshold=threshold)
    return sorted(files_a.intersection(files_b))


def collapse_rt_related_entries(ms2_df: pd.DataFrame, rt_tol_min: float = 0.01,
                                  neutral_ppm: float = 10.0, frag_ppm: float = 5.0,
                                  sample_cols: Optional[List[str]] = None,
                                  sample_filenames: Optional[List[str]] = None) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Collapse coeluting related CD compound rows to one MGF representative.

    Important resolver rules:
      - any relation is accepted only when the two features are present in at
        least one same raw file/sample;
      - MS2-child edges are treated as direct parent-child evidence, not as
        transitive network evidence. A shared fragment/child cannot bridge two
        different parent features into the same final row_id. Therefore:
          * adduct/multimer and simple transformation edges may build connected
            components only after the same-raw check;
          * MS2-child edges are merged only when the child has one unique parent
            component in that same-raw context;
          * if two parent candidates share the same child, all direct parent-child
            relations can be annotated, but the child is operationally collapsed
            only once and never bridges/fuses those parent components.

    The function does not alter the original CD compound IDs. It adds audit columns,
    chooses one representative row for each resolved component, and returns:
        kept_df, removed_df, relation_df
    """
    if ms2_df.empty:
        empty_rel = pd.DataFrame(columns=["compound_id_1", "compound_id_2", "relation", "rt_delta_min", "mz_1", "mz_2"])
        return ms2_df.copy(), ms2_df.iloc[0:0].copy(), empty_rel

    work = ms2_df.copy().reset_index(drop=True)
    ids = list(work.index)
    uf = UnionFind(ids)
    relations = []
    child_edges = []
    work["_inferred_secondary_adduct_by_delta"] = 0

    # Sort by RT to limit comparisons.
    order = work.sort_values("RT_min").index.tolist()
    for pos_i, idx_i in enumerate(order):
        rt_i = safe_float(work.loc[idx_i, "RT_min"], None)
        if rt_i is None:
            continue
        for idx_j in order[pos_i + 1:]:
            rt_j = safe_float(work.loc[idx_j, "RT_min"], None)
            if rt_j is None:
                continue
            if rt_j - rt_i > rt_tol_min:
                break
            common_raw_files = shared_raw_files(
                work.loc[idx_i], work.loc[idx_j], sample_cols, sample_filenames, threshold=0.0
            )
            if not common_raw_files:
                continue

            relation = ion_relation_label(work.loc[idx_i], work.loc[idx_j], neutral_ppm=neutral_ppm, frag_ppm=frag_ppm)
            if relation:
                parent_idx = None
                child_idx = None
                if relation == "ms2_child_fragment_match":
                    parent_label, child_label = child_relation_parent_child_indices(work.loc[idx_i], work.loc[idx_j], frag_ppm=frag_ppm)
                    if parent_label == "a" and child_label == "b":
                        parent_idx, child_idx = idx_i, idx_j
                    elif parent_label == "b" and child_label == "a":
                        parent_idx, child_idx = idx_j, idx_i
                    if parent_idx is not None and child_idx is not None:
                        child_edges.append((parent_idx, child_idx))
                else:
                    # Non-child evidence can safely build a transitive component.
                    uf.union(idx_i, idx_j)
                    if str(relation).startswith("adduct_compatible_delta_"):
                        sec_i, sec_j = adduct_compatible_delta_secondary_flags(work.loc[idx_i], work.loc[idx_j], str(relation))
                        if sec_i:
                            work.loc[idx_i, "_inferred_secondary_adduct_by_delta"] = 1
                        if sec_j:
                            work.loc[idx_j, "_inferred_secondary_adduct_by_delta"] = 1

                relations.append({
                    "compound_id_1": work.loc[idx_i, "Compounds ID"],
                    "compound_id_2": work.loc[idx_j, "Compounds ID"],
                    "relation": relation,
                    "rt_delta_min": abs(rt_j - rt_i),
                    "mz_1": work.loc[idx_i, "Precursor_mz"],
                    "mz_2": work.loc[idx_j, "Precursor_mz"],
                    "ion_1": work.loc[idx_i, "Reference Ion"],
                    "ion_2": work.loc[idx_j, "Reference Ion"],
                    "parent_compound_id": "" if parent_idx is None else work.loc[parent_idx, "Compounds ID"],
                    "child_compound_id": "" if child_idx is None else work.loc[child_idx, "Compounds ID"],
                    "shared_raw_files": "; ".join(common_raw_files),
                })

    # Assign MS2-child edges after non-child components have been built.
    #
    # Important: a shared child must not bridge/fuse two different parent components.
    # However, the child itself should still be removed/collapsed when there is direct
    # parent-child evidence. Therefore we do NOT union all parent-child edges.
    # Instead, each child component is assigned to exactly one direct parent component.
    # If a child has multiple direct parents, the owner parent is chosen deterministically
    # by the same representative priority used for MGF selection, with higher m/z/area
    # breaking ties. This preserves direct A-vs-B child checks while preventing
    # parent A <- child X -> parent B bridging.
    base_root_by_idx = {idx: uf.find(idx) for idx in ids}
    child_root_to_parent_roots = {}
    child_root_to_parent_indices = {}
    for parent_idx, child_idx in child_edges:
        parent_root = base_root_by_idx.get(parent_idx, uf.find(parent_idx))
        child_root = base_root_by_idx.get(child_idx, uf.find(child_idx))
        if parent_root == child_root:
            continue
        child_root_to_parent_roots.setdefault(child_root, set()).add(parent_root)
        child_root_to_parent_indices.setdefault(child_root, []).append(parent_idx)

    # Root-to-owner mapping for child components. Parent roots remain independent; only
    # the child root is assigned to one owner parent root for final row_id purposes.
    child_root_owner = {}
    for child_root, parent_roots in child_root_to_parent_roots.items():
        if not parent_roots:
            continue
        if len(parent_roots) == 1:
            child_root_owner[child_root] = next(iter(parent_roots))
            continue

        # Multiple direct parents share the same child. Select one owner without
        # merging the parent components together. Prefer the best parent candidate
        # according to molecular-ion status, monomer-like status, m/z and area.
        candidate_parent_indices = [
            idx for idx in child_root_to_parent_indices.get(child_root, [])
            if base_root_by_idx.get(idx) in parent_roots
        ]
        if candidate_parent_indices:
            best_parent_idx = max(candidate_parent_indices, key=lambda idx: representative_sort_key(work.loc[idx]))
            child_root_owner[child_root] = base_root_by_idx.get(best_parent_idx, uf.find(best_parent_idx))
        else:
            child_root_owner[child_root] = sorted(parent_roots)[0]

    def final_root_for_idx(idx: int) -> int:
        root = base_root_by_idx.get(idx, uf.find(idx))
        seen = set()
        # Follow ownership chains if a child component is assigned to a parent that is
        # itself assigned upward. Guard against accidental loops.
        while root in child_root_owner and root not in seen:
            seen.add(root)
            root = child_root_owner[root]
        return root

    work["resolved_component_root"] = [final_root_for_idx(i) for i in ids]
    root_to_compound = {}
    for root in sorted(set(work["resolved_component_root"])):
        root_to_compound[root] = len(root_to_compound) + 1
    work["resolved_compound_id"] = work["resolved_component_root"].map(root_to_compound)

    selected_indices = []
    selected_by_component = {}
    for comp_id, group in work.groupby("resolved_compound_id"):
        candidates = group.copy()
        candidates["_rep_key"] = candidates.apply(representative_sort_key, axis=1)
        best_idx = candidates.sort_values("_rep_key", ascending=False).index[0]
        selected_indices.append(best_idx)
        selected_by_component[comp_id] = {
            "selected_index": best_idx,
            "selected_compound_id": work.loc[best_idx, "Compounds ID"],
            "selected_mz": work.loc[best_idx, "Precursor_mz"],
            "selected_ion": work.loc[best_idx, "Reference Ion"],
        }

    work["selected_for_mgf"] = work.index.isin(selected_indices).astype(int)
    work["selected_compound_id"] = work["resolved_compound_id"].map(lambda x: selected_by_component[x]["selected_compound_id"])
    work["selected_mz"] = work["resolved_compound_id"].map(lambda x: selected_by_component[x]["selected_mz"])
    work["selected_ion"] = work["resolved_compound_id"].map(lambda x: selected_by_component[x]["selected_ion"])
    work["resolver_label"] = work.apply(
        lambda r: "MGF_representative" if int(r["selected_for_mgf"]) == 1 else "redundant_same_rt_related_ion",
        axis=1,
    )

    kept = work[work["selected_for_mgf"] == 1].copy().reset_index(drop=True)
    removed = work[work["selected_for_mgf"] == 0].copy().reset_index(drop=True)
    rel_df = pd.DataFrame(relations)
    return kept, removed, rel_df


# ---------------------------------------------------------------------
# Study Information metadata helpers
# ---------------------------------------------------------------------


def find_study_information_table(table_paths: List[str]) -> Tuple[pd.DataFrame, str]:
    """Find the exported Compound Discoverer Study Information table.

    The table is recognized mainly by the presence of a File Name-like column.
    All columns, except File Name, are converted to metadata ATTRIBUTE_* columns.
    """
    best_df = None
    best_path = ""
    best_score = -1

    for p in table_paths:
        if not p or not os.path.exists(p):
            continue
        try:
            df = read_table_auto(p)
        except Exception:
            continue

        file_col = first_existing_col(df, [
            "File Name", "Filename", "FileName", "Raw File", "Raw File Name",
            "Sample File", "Sample Filename", "Data File", "Data File Name"
        ])
        if file_col is None:
            continue

        cols_norm = {norm(c) for c in df.columns}
        score = 10
        for expected in ["sampletype", "samplename", "sampleid", "group", "batch", "injectiontype"]:
            if expected in cols_norm:
                score += 2
        # Penalize a Compounds-like table if it somehow has a File Name column too.
        if {"rtinmin", "mz", "referenceion"}.issubset(cols_norm):
            score -= 5

        if score > best_score:
            best_df = df
            best_path = p
            best_score = score

    if best_df is None:
        raise RuntimeError(
            "Could not find the exported CD 'Study Information' table in NODEARGS. "
            "In the Scripting Node requested tables, add: Study Information: File Name "
            "and the metadata columns you want to export."
        )
    return best_df, best_path


def metadata_key(value: str) -> str:
    """Normalize a filename for matching quant table sample names to Study Information."""
    if value is None or pd.isna(value):
        return ""
    text = str(value).strip().replace("\\", "/").split("/")[-1]
    text = clean_sample_filename(text)
    return text.lower()


def cd_column_to_metadata_attribute_column(col: str) -> str:
    """Convert CD Study Information column names to metadata column names."""
    clean = re.sub(r"[^A-Za-z0-9]+", " ", str(col).strip())
    parts = [p for p in clean.split() if p]
    if not parts:
        return "ATTRIBUTE_Metadata"
    return "ATTRIBUTE_" + "".join(p[:1].upper() + p[1:] for p in parts)


def make_unique_columns(cols: List[str]) -> List[str]:
    """Ensure unique column names while preserving order."""
    seen = {}
    out = []
    for c in cols:
        if c not in seen:
            seen[c] = 1
            out.append(c)
        else:
            seen[c] += 1
            out.append(f"{c}_{seen[c]}")
    return out


# ---------------------------------------------------------------------
# Output writers
# ---------------------------------------------------------------------


def list_to_semicolon_string(values, ndigits=8):
    if not isinstance(values, list) or len(values) == 0:
        return ""
    return ";".join([("{: ." + str(ndigits) + "f}").format(float(v)).strip() for v in values])


def get_present_filenames_for_feature(row, sample_cols: List[str], sample_filenames: List[str], threshold: float = 0.0) -> str:
    """Return raw filenames where a feature is present, separated by semicolon.

    Presence is inferred from the CD area columns retained for the quant table.
    A filename is included when the corresponding area is greater than threshold.
    """
    present = []
    for col, fname in zip(sample_cols, sample_filenames):
        value = safe_float(row.get(col, 0), 0.0)
        if value is not None and value > float(threshold):
            present.append(fname)

    unique_present = []
    seen = set()
    for fname in present:
        if fname not in seen:
            unique_present.append(fname)
            seen.add(fname)

    return ";".join(unique_present)


def write_mgf(
    results_df: pd.DataFrame,
    output_mgf_path: Path,
    sample_cols: Optional[List[str]] = None,
    sample_filenames: Optional[List[str]] = None,
    min_ms2_peaks: int = 1,
) -> int:
    if sample_cols is None:
        sample_cols = []
    if sample_filenames is None:
        sample_filenames = []

    n_written = 0
    with open(output_mgf_path, "w", encoding="utf-8") as mgf:
        for _, row in results_df.iterrows():
            mz_values = row["MS2_mz_list"]
            int_values = row["MS2_intensity_list"]
            if not isinstance(mz_values, list) or not isinstance(int_values, list):
                continue
            if len(mz_values) < min_ms2_peaks or len(int_values) < min_ms2_peaks:
                continue

            row_id = int(row["feature_id"])
            actual_feature_id = safe_int(row.get("actual_feature_id", ""), None)
            if actual_feature_id is None:
                actual_feature_id = safe_int(row.get("selected_associated_feature_id", ""), None)
            if actual_feature_id is None:
                actual_feature_id = safe_int(row.get("Compounds ID", ""), row_id)
            precursor_mz = float(row["Precursor_mz"])
            rt_min = float(row["RT_min"])
            rt_seconds = rt_min * 60.0
            ion_type, _, polarity, mgf_charge = parse_reference_ion(row.get("Reference Ion", ""))
            title = f"ROW_{row_id}_FEATURE_{actual_feature_id}_CID_{row['Compounds ID']}_mz{precursor_mz:.6f}_RT{rt_min:.4f}"
            filenames = get_present_filenames_for_feature(row, sample_cols, sample_filenames, threshold=0.0)

            mgf.write("BEGIN IONS\n")
            mgf.write(f"SCANS={row_id}\n")
            mgf.write(f"FEATURE_ID={actual_feature_id}\n")
            mgf.write(f"CID={row['Compounds ID']}\n")
            mgf.write(f"TITLE={title}\n")
            mgf.write(f"FILENAME={filenames}\n")
            mgf.write(f"PEPMASS={precursor_mz:.8f}\n")
            mgf.write("MSLEVEL=2\n")
            mgf.write(f"CHARGE={mgf_charge}\n")
            mgf.write(f"RTINSECONDS={rt_seconds:.4f}\n")
            mgf.write(f"RTINMINUTES={rt_min:.6f}\n")
            mgf.write(f"ADDUCT={ion_type}\n")
            mgf.write(f"IONMODE={polarity}\n")

            for mz, inten in zip(mz_values, int_values):
                mgf.write(f"{float(mz):.8f} {float(inten):.6f}\n")
            mgf.write("END IONS\n\n")
            n_written += 1
    return n_written


def write_quant_table(
    results_df: pd.DataFrame,
    output_quant_path: Path,
    sample_cols: List[str],
    sample_filenames: List[str],
) -> pd.DataFrame:
    rows = []
    for _, row in results_df.iterrows():
        feature_id = int(row["feature_id"])
        actual_feature_id = safe_int(row.get("actual_feature_id", ""), None)
        if actual_feature_id is None:
            actual_feature_id = safe_int(row.get("selected_associated_feature_id", ""), None)
        if actual_feature_id is None:
            actual_feature_id = safe_int(row.get("Compounds ID", ""), feature_id)
        ion_type, _, polarity, _ = parse_reference_ion(row.get("Reference Ion", ""))

        out = {
            "row ID": feature_id,
            "row m/z": float(row["Precursor_mz"]),
            "row retention time": float(row["RT_min"]),
            "correlation group ID": feature_id,
            "annotation network number": feature_id,
            "best ion": ion_type,
            "auto MS2 verify": int(row.get("has_ms2", 0)),
            "identified by n=": 0,
            "partners": "",
            "neutral M mass": "",
            "compound_id": row["Compounds ID"],
            "feature_id": actual_feature_id,
            "reference_ion": row.get("Reference Ion", ""),
            "polarity": polarity,
            "n_ms2_fragments": int(row.get("n_ms2_fragments", 0)),
        }

        if sample_cols:
            for col, fname in zip(sample_cols, sample_filenames):
                out[f"{fname} Peak area"] = safe_float(row.get(col, 0), 0.0)
        else:
            out["CD_export.raw Peak area"] = 1.0

        rows.append(out)

    quant_df = pd.DataFrame(rows)
    quant_df.to_csv(output_quant_path, index=False)
    return quant_df


def write_metadata(
    output_metadata_path: Path,
    sample_filenames: List[str],
    study_info_df: pd.DataFrame,
) -> pd.DataFrame:
    """Write metadata using CD Study Information.

    Rules:
      - CD 'File Name' becomes MGF 'filename'.
      - Every other Study Information column becomes ATTRIBUTE_<CleanColumnName>.
      - Only samples retained in the quant table are written, in quant table order.
    """
    if not sample_filenames:
        sample_filenames = ["CD_export.raw"]

    file_col = first_existing_col(study_info_df, [
        "File Name", "Filename", "FileName", "Raw File", "Raw File Name",
        "Sample File", "Sample Filename", "Data File", "Data File Name"
    ])
    if file_col is None:
        raise RuntimeError(
            "The Study Information table was found, but it has no 'File Name' column. "
            "Export at least: Study Information: File Name."
        )

    attr_source_cols = [c for c in study_info_df.columns if c != file_col]
    attr_cols = make_unique_columns([cd_column_to_metadata_attribute_column(c) for c in attr_source_cols])

    study_by_file = {}
    for _, row in study_info_df.iterrows():
        key = metadata_key(row.get(file_col, ""))
        if key and key not in study_by_file:
            study_by_file[key] = row

    rows = []
    missing = []
    for fname in sample_filenames:
        key = metadata_key(fname)
        matched = study_by_file.get(key)
        out = {"filename": fname}
        for source_col, attr_col in zip(attr_source_cols, attr_cols):
            out[attr_col] = matched.get(source_col, "") if matched is not None else ""
        if matched is None:
            missing.append(fname)
        rows.append(out)

    metadata_df = pd.DataFrame(rows)
    metadata_df.to_csv(output_metadata_path, sep="\t", index=False)

    metadata_df.attrs["study_info_rows"] = int(len(study_info_df))
    metadata_df.attrs["study_info_attribute_columns"] = int(len(attr_cols))
    metadata_df.attrs["metadata_unmatched_filenames"] = missing
    return metadata_df


def compute_area_for_audit(row, area_max_col: Optional[str] = None) -> float:
    """Return the CD Area Max value for the audit workbook.

    The audit column 'area_max' must reflect Compound Discoverer's Area (Max.)
    value, not the sum of sample areas. The value is first read from the
    selected/actual associated feature MaxArea from SQLite when available;
    otherwise it falls back to the exported Compounds table Area Max column.
    """
    value = safe_float(row.get("_audit_area_max"), None)
    if value is not None:
        return float(value)
    if area_max_col:
        value = safe_float(row.get(area_max_col), None)
        if value is not None:
            return float(value)
    return 0.0


def compute_calc_mw_for_audit(row, calc_mw_col: Optional[str] = None):
    """Return calculated molecular weight for the audit workbook.

    Prefer the MolecularWeight of the actual CD associated feature from the
    .cdResult SQLite database. If unavailable, fall back to an exported
    Compounds table Calc. MW-like column. Blank is returned if neither exists.
    """
    value = safe_float(row.get("_audit_calc_mw"), None)
    if value is not None:
        return float(value)
    if calc_mw_col:
        value = safe_float(row.get(calc_mw_col), None)
        if value is not None:
            return float(value)
    return ""


def _true_feature_id_from_resolver_row(rr):
    """Return the actual CD associated feature/ion ID used for audit display."""
    value = safe_int(rr.get("actual_feature_id", ""), None)
    if value is None:
        value = safe_int(rr.get("selected_associated_feature_id", ""), None)
    if value is None:
        value = safe_int(rr.get("Compounds ID", ""), None)
    return value if value is not None else ""


def build_consistent_relations_and_resolved_tables(
    selected_df: pd.DataFrame,
    same_rt_removed_df: pd.DataFrame,
    same_rt_relation_df: pd.DataFrame,
    feature_labels_df: pd.DataFrame,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Build mutually consistent Relations and Resolved compounds audit sheets.

    Rules:
      - Relations contains direct edges actually detected by the same-RT resolver.
      - Direct MS2-child edges can be shown under every compatible parent,
        while the child remains non-selected and parent components are not bridged.
      - Relations uses true feature/ion IDs, not CD compound-group IDs.
      - Relation type, delta_mz, delta_rt, ion_a and ion_b are recalculated on the displayed feature rows.
      - Resolved compounds feature_ids is derived from the selected representative
        plus all features appearing in Relations for that resolved component.
      - Therefore every feature shown in a multi-feature feature_ids list is
        justified by at least one row in Relations, and every Relations feature
        appears in the corresponding feature_ids list.
    """
    rel_columns = [
        "row_id", "feature_a", "feature_b", "selected_feature_id", "relation_type", "direction",
        "rt_a_min", "rt_b_min", "mz_a", "mz_b", "ion_a", "ion_b",
        "calc_mw_a", "calc_mw_b", "delta_rt_min", "delta_mz", "delta_calc_mw"
    ]
    resolved_columns = [
        "compound_id", "n_features", "selected_feature_id",
        "row_id", "selected_rt_min", "selected_mz",
        "selected_calc_mw", "selected_area_max", "selected_ion", "feature_ids"
    ]

    if selected_df is None or selected_df.empty:
        return pd.DataFrame(columns=rel_columns), pd.DataFrame(columns=resolved_columns)

    resolver_parts = [selected_df.copy()]
    if same_rt_removed_df is not None and not same_rt_removed_df.empty:
        resolver_parts.append(same_rt_removed_df.copy())
    resolver_all_df = pd.concat(resolver_parts, ignore_index=True, sort=False)

    # Map original CD compound-group ID -> row carrying true feature ID and resolver component.
    by_cd_compound = {}
    for _, rr in resolver_all_df.iterrows():
        cid_key = str(rr.get("Compounds ID", ""))
        if cid_key:
            by_cd_compound[cid_key] = rr

    # Map true feature ID -> compact audit Feature labels row.
    feature_label_by_feature_id = {}
    for _, fr in feature_labels_df.iterrows():
        feature_label_by_feature_id[str(fr.get("feature_id", ""))] = fr

    # Map internal resolver component -> final exported row_id.
    # This is the useful ID for matching MGF SCANS and quant table row ID.
    row_id_by_component = {}
    selected_feature_id_by_component = {}
    for _, sel in selected_df.iterrows():
        comp_key = str(sel.get("resolved_compound_id", ""))
        if comp_key:
            row_id_by_component[comp_key] = sel.get("feature_id", "")
            selected_feature_id_by_component[comp_key] = _true_feature_id_from_resolver_row(sel)

    # Direct relations, filtered to final resolver components and rewritten using true feature IDs.
    relation_rows = []
    relation_features_by_component = {}
    relation_count_by_component = {}

    if same_rt_relation_df is not None and not same_rt_relation_df.empty:
        for _, r in same_rt_relation_df.iterrows():
            cid1 = str(r.get("compound_id_1", ""))
            cid2 = str(r.get("compound_id_2", ""))
            row1 = by_cd_compound.get(cid1)
            row2 = by_cd_compound.get(cid2)
            if row1 is None or row2 is None:
                continue

            comp1 = str(row1.get("resolved_compound_id", ""))
            comp2 = str(row2.get("resolved_compound_id", ""))

            f1 = _true_feature_id_from_resolver_row(row1)
            f2 = _true_feature_id_from_resolver_row(row2)
            if f1 == "" or f2 == "" or str(f1) == str(f2):
                continue

            # Re-evaluate the relation using the actual displayed feature rows,
            # not the parent CD compound-group rows. Therefore ion_a, ion_b, delta_rt_min
            # and delta_mz always describe feature_a and feature_b exactly.
            audit_row1 = audit_relation_row_from_actual_features(row1)
            audit_row2 = audit_relation_row_from_actual_features(row2)
            relation_type = ion_relation_label(audit_row1, audit_row2, neutral_ppm=10.0, frag_ppm=5.0)
            if not relation_type:
                continue

            # Normal adduct/neutral-mass/transformation edges are written only inside
            # the final resolver component that they actually collapse.
            # MS2-child edges are different: the child can be annotated under every
            # direct parent candidate, even when the child has been operationally
            # assigned to only one owner for the MGF collapse. This preserves the
            # A-vs-B evidence without using a shared child as a bridge between parents.
            parent_fid = ""
            child_fid = ""
            relation_comp = comp1
            collapse_action = "collapsed_same_rt_component"
            if relation_type == "ms2_child_fragment_match":
                parent_label, child_label = child_relation_parent_child_indices(audit_row1, audit_row2, frag_ppm=5.0)
                if parent_label == "a" and child_label == "b":
                    relation_comp = comp1
                    parent_fid, child_fid = f1, f2
                elif parent_label == "b" and child_label == "a":
                    relation_comp = comp2
                    parent_fid, child_fid = f2, f1
                else:
                    continue
                if relation_comp == "":
                    continue
                if comp1 == comp2:
                    collapse_action = "child_collapsed_under_this_parent"
                else:
                    collapse_action = "audit_child_under_this_parent_not_parent_bridge"
            else:
                if comp1 == "" or comp1 != comp2:
                    continue
                relation_comp = comp1

            if relation_comp == "":
                continue

            mz1 = safe_float(audit_row1.get("Precursor_mz"), None)
            mz2 = safe_float(audit_row2.get("Precursor_mz"), None)
            rt1 = safe_float(audit_row1.get("RT_min"), None)
            rt2 = safe_float(audit_row2.get("RT_min"), None)
            delta_mz = "" if mz1 is None or mz2 is None else abs(mz1 - mz2)
            delta_rt = "" if rt1 is None or rt2 is None else abs(rt1 - rt2)
            ion1 = audit_row1.get("Reference Ion", "")
            ion2 = audit_row2.get("Reference Ion", "")
            calc_mw1 = compute_calc_mw_for_audit(audit_row1, None)
            calc_mw2 = compute_calc_mw_for_audit(audit_row2, None)
            calc_mw1_num = safe_float(calc_mw1, None)
            calc_mw2_num = safe_float(calc_mw2, None)
            delta_calc_mw = "" if calc_mw1_num is None or calc_mw2_num is None else abs(calc_mw1_num - calc_mw2_num)

            relation_rows.append({
                "row_id": row_id_by_component.get(relation_comp, ""),
                "feature_a": f1,
                "feature_b": f2,
                "selected_feature_id": selected_feature_id_by_component.get(relation_comp, ""),
                "relation_type": relation_type,
                "direction": "undirected_same_rt_component",
                "rt_a_min": rt1 if rt1 is not None else "",
                "rt_b_min": rt2 if rt2 is not None else "",
                "mz_a": mz1 if mz1 is not None else "",
                "mz_b": mz2 if mz2 is not None else "",
                "ion_a": ion1,
                "ion_b": ion2,
                "calc_mw_a": calc_mw1_num if calc_mw1_num is not None else "",
                "calc_mw_b": calc_mw2_num if calc_mw2_num is not None else "",
                "delta_rt_min": delta_rt,
                "delta_mz": delta_mz,
                "delta_calc_mw": delta_calc_mw,
            })
            relation_count_by_component[relation_comp] = relation_count_by_component.get(relation_comp, 0) + 1
            relation_features_by_component.setdefault(relation_comp, [])
            for fid in [f1, f2]:
                if fid not in relation_features_by_component[relation_comp]:
                    relation_features_by_component[relation_comp].append(fid)

    relations_df = pd.DataFrame(relation_rows, columns=rel_columns)

    resolved_rows = []
    for _, sel in selected_df.iterrows():
        comp_value = str(sel.get("resolved_compound_id", ""))
        selected_feature_id_value = _true_feature_id_from_resolver_row(sel)
        fl = feature_label_by_feature_id.get(str(selected_feature_id_value))
        if fl is None:
            # Fallback to selected row values if the compact Feature labels row cannot be found.
            fl = {
                "compound_id": "",
                "feature_id": selected_feature_id_value,
                "row_id": sel.get("feature_id", ""),
                "rt_min": safe_float(sel.get("RT_min"), ""),
                "mz": safe_float(sel.get("Precursor_mz"), ""),
                "calc_mw": compute_calc_mw_for_audit(sel, None),
                "area_max": safe_float(sel.get("_audit_area_max"), ""),
                "selected_reference_ion": sel.get("Reference Ion", ""),
            }

        if comp_value and "row_id" in resolver_all_df.columns:
            component_df = resolver_all_df.loc[resolver_all_df["row_id"].astype(str) == comp_value].copy()
        else:
            component_df = sel.to_frame().T.copy()

        if relation_count_by_component.get(comp_value, 0) > 0:
            component_feature_ids = []
            # Start with selected representative, then add all directly justified relation nodes.
            for fid in [selected_feature_id_value] + relation_features_by_component.get(comp_value, []):
                if fid != "" and fid not in component_feature_ids:
                    component_feature_ids.append(fid)
        else:
            # Singleton: no relation is needed or written.
            component_feature_ids = [selected_feature_id_value] if selected_feature_id_value != "" else []

        resolved_rows.append({
            "compound_id": fl["compound_id"],
            "n_features": int(len(component_feature_ids)),
            "selected_feature_id": fl["feature_id"],
            "row_id": fl["row_id"],
            "selected_rt_min": fl["rt_min"],
            "selected_mz": fl["mz"],
            "selected_calc_mw": fl.get("calc_mw", ""),
            "selected_area_max": fl["area_max"],
            "selected_ion": parse_reference_ion(fl.get("selected_reference_ion", ""))[0],
            "feature_ids": "; ".join(str(x) for x in component_feature_ids),
        })

    resolved_compounds_df = pd.DataFrame(resolved_rows, columns=resolved_columns)
    return relations_df, resolved_compounds_df


def write_feature_resolver_audit(
    results_df: pd.DataFrame,
    selected_df: pd.DataFrame,
    blank_removed_df: pd.DataFrame,
    recurrent_raw_removed_df: pd.DataFrame,
    purity_removed_df: pd.DataFrame,
    same_rt_removed_df: pd.DataFrame,
    same_rt_relation_df: pd.DataFrame,
    output_audit_path: Path,
    sample_cols: List[str],
    nonblank_sample_cols: List[str],
    blank_sample_cols: List[str],
    sample_filenames: List[str],
    blank_sample_filenames: List[str],
    area_max_col: Optional[str],
    calc_mw_col: Optional[str],
    metadata_df: pd.DataFrame,
    study_info_path: str,
    purity_col: Optional[str],
    purity_filter_applied: bool,
    purity_threshold: float,
    errors: List[str],
) -> None:
    """Write the final audit workbook with same-RT resolver decisions included."""
    selected_original_ids = set(selected_df["Compounds ID"].astype(str).tolist()) if not selected_df.empty else set()
    blank_removed_original_ids = set(blank_removed_df["Compounds ID"].astype(str).tolist()) if not blank_removed_df.empty else set()
    recurrent_raw_removed_original_ids = set(recurrent_raw_removed_df["Compounds ID"].astype(str).tolist()) if recurrent_raw_removed_df is not None and not recurrent_raw_removed_df.empty else set()
    purity_removed_original_ids = set(purity_removed_df["Compounds ID"].astype(str).tolist()) if purity_removed_df is not None and not purity_removed_df.empty else set()
    same_rt_removed_original_ids = set(same_rt_removed_df["Compounds ID"].astype(str).tolist()) if same_rt_removed_df is not None and not same_rt_removed_df.empty else set()

    mgf_row_map = {}
    if not selected_df.empty:
        for _, r in selected_df.iterrows():
            mgf_row_map[str(r.get("Compounds ID", ""))] = r.get("feature_id", "")

    feature_rows = []
    for audit_idx, (_, row) in enumerate(results_df.iterrows(), start=1):
        original_cid = str(row.get("Compounds ID", ""))
        has_ms2 = int(row.get("n_ms2_fragments", 0)) > 0
        selected = original_cid in selected_original_ids
        blank_removed = original_cid in blank_removed_original_ids
        recurrent_raw_removed = original_cid in recurrent_raw_removed_original_ids
        purity_removed = original_cid in purity_removed_original_ids
        same_rt_removed = original_cid in same_rt_removed_original_ids
        ion_type, _, _, _ = parse_reference_ion(row.get("Reference Ion", ""))
        representative_ion_reassigned = bool(row.get("representative_ion_reassigned", False))

        if selected:
            selection_reason = "selected_representative_MS2_feature_not_present_in_blank"
            removal_category = "retained_selected_for_mgf"
            role = "selected_for_mgf_export"
        elif blank_removed:
            selection_reason = "removed_MS2_feature_present_in_blank"
            removal_category = "not_exported_present_in_blank"
            role = "removed_blank_present"
        elif recurrent_raw_removed:
            selection_reason = "removed_feature_present_in_at_least_3_nonblank_raw_files"
            removal_category = "not_exported_present_in_many_raw_files"
            role = "removed_present_in_many_raw_files"
        elif purity_removed:
            selection_reason = "removed_low_ms2_purity"
            removal_category = "not_exported_low_ms2_purity"
            role = "removed_low_ms2_purity"
        elif same_rt_removed:
            selection_reason = "removed_redundant_same_rt_related_ion"
            removal_category = "not_exported_same_rt_related_ion"
            role = "removed_same_rt_related_ion"
        elif has_ms2:
            selection_reason = "not_selected_after_filtering"
            removal_category = "not_exported_other_filter"
            role = "not_selected"
        else:
            selection_reason = "audit_reference_no_ms2_not_exported_to_mgf"
            removal_category = "not_exported_no_ms2"
            role = "no_ms2_not_exported"

        labels = []
        labels.append("has_ms2" if has_ms2 else "no_ms2")
        labels.append("selected_for_mgf" if selected else "not_selected_for_mgf")
        if blank_removed:
            labels.append("blank_present")
        if recurrent_raw_removed:
            labels.append("present_in_at_least_3_nonblank_raw_files")
        if purity_removed:
            if pd.isna(row.get("_ms2_purity_pct", pd.NA)):
                labels.append("missing_ms2_purity")
            else:
                labels.append("low_ms2_purity")
        if same_rt_removed:
            labels.append("same_rt_related_removed")
        if representative_ion_reassigned:
            labels.append("representative_ion_reassigned")

        feature_rows.append({
            "compound_id": audit_idx,
            "feature_id": row.get("actual_feature_id", row.get("selected_associated_feature_id", "")),
            "row_id": int(mgf_row_map.get(original_cid)) if selected and safe_int(mgf_row_map.get(original_cid)) is not None else "",
            "rt_min": safe_float(row.get("RT_min"), ""),
            "mz": safe_float(row.get("Precursor_mz"), ""),
            "calc_mw": compute_calc_mw_for_audit(row, calc_mw_col),
            "area_max": compute_area_for_audit(row, area_max_col),
            "has_ms2": "TRUE" if has_ms2 else "FALSE",
            "selected_for_mgf": "TRUE" if selected else "FALSE",
            "selection_reason": selection_reason,
            "removal_category": removal_category,
            "resolver_feature_role": role,
            "labels": "; ".join(labels),
            "n_ms2_fragments": int(row.get("n_ms2_fragments", 0)),
            "ms2_purity_percent": safe_float(row.get("_ms2_purity_pct"), ""),
            "original_reference_ion": row.get("Original Reference Ion", row.get("Reference Ion", "")),
            "selected_reference_ion": row.get("Reference Ion", ""),
            "representative_ion_reassigned": "TRUE" if representative_ion_reassigned else "FALSE",
            "selected_reference_source": row.get("selected_reference_source", ""),
        })

    feature_labels_df = pd.DataFrame(feature_rows)
    removed_rows_df = feature_labels_df.loc[feature_labels_df["selected_for_mgf"] != "TRUE"].copy()

    # Build Relations and Resolved compounds together, so they describe the same
    # final resolver graph. This guarantees that multi-feature feature_ids are
    # justified by direct Relations rows and that every feature in Relations is
    # present in the corresponding feature_ids list.
    relations_df, resolved_compounds_df = build_consistent_relations_and_resolved_tables(
        selected_df=selected_df,
        same_rt_removed_df=same_rt_removed_df,
        same_rt_relation_df=same_rt_relation_df,
        feature_labels_df=feature_labels_df,
    )

    summary_df = pd.DataFrame([
        {"Parameter": "audit_created", "Value": datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
        {"Parameter": "total_cd_entries_read", "Value": int(len(results_df))},
        {"Parameter": "entries_with_ms2_before_blank_filtering", "Value": int((results_df["n_ms2_fragments"].astype(int) > 0).sum())},
        {"Parameter": "entries_removed_present_in_blank", "Value": int(len(blank_removed_df))},
        {"Parameter": "entries_removed_by_recurrent_nonblank_raw_count_filter", "Value": 0},
        {"Parameter": "entries_removed_low_ms2_purity", "Value": int(len(purity_removed_df)) if purity_removed_df is not None else 0},
        {"Parameter": "same_rt_related_entries_removed", "Value": int(len(same_rt_removed_df)) if same_rt_removed_df is not None else 0},
        {"Parameter": "same_rt_relations_detected", "Value": int(len(relations_df)) if relations_df is not None else 0},
        {"Parameter": "representative_entries_exported_to_mgf", "Value": int(len(selected_df))},
        {"Parameter": "representative_ion_reassigned_count", "Value": int(pd.Series(selected_df.get("representative_ion_reassigned", False)).fillna(False).astype(bool).sum())},
        {"Parameter": "representative_ion_reassigned_rule", "Value": "Among final exported representatives, TRUE when the canonicalized original CD Reference Ion differs from the final selected Reference Ion; missing/unknown ion labels are not counted as reassigned"},
        {"Parameter": "sample_area_columns_detected", "Value": int(len(sample_cols))},
        {"Parameter": "nonblank_sample_columns_in_quant", "Value": int(len(nonblank_sample_cols))},
        {"Parameter": "blank_sample_columns_removed_from_quant", "Value": int(len(blank_sample_cols))},
        {"Parameter": "blank_samples_detected", "Value": ", ".join(blank_sample_filenames) if blank_sample_filenames else "none"},
        {"Parameter": "all_sample_filenames_detected", "Value": ", ".join(sample_filenames) if sample_filenames else "none"},
        {"Parameter": "metadata_rows", "Value": int(len(metadata_df))},
        {"Parameter": "study_information_table", "Value": study_info_path},
        {"Parameter": "study_information_rows", "Value": metadata_df.attrs.get("study_info_rows", "")},
        {"Parameter": "study_information_attribute_columns", "Value": metadata_df.attrs.get("study_info_attribute_columns", "")},
        {"Parameter": "metadata_unmatched_filenames", "Value": "; ".join(metadata_df.attrs.get("metadata_unmatched_filenames", [])) or "none"},
        {"Parameter": "warnings_or_errors_recorded", "Value": int(len(errors))},
        {"Parameter": "ms2_purity_column_detected", "Value": purity_col or "none"},
        {"Parameter": "ms2_purity_filter_applied", "Value": "TRUE" if purity_filter_applied else "FALSE"},
        {"Parameter": "ms2_purity_source_rule", "Value": "exported Compounds column if available; otherwise retrieved from .cdResult SQLite via linked MassSpectrumInfoItems or compound tables"},
        {"Parameter": "ms2_purity_threshold", "Value": f">= {purity_threshold:g}"},
        {"Parameter": "ms2_purity_strict_missing_rule", "Value": "features with missing MS2/Isolation Purity are excluded because purity >= threshold is not demonstrable"},
        {"Parameter": "active_mass_difference_rules", "Value": "; ".join([name for name, _mass in MASS_DIFFERENCE_RULES])},
        {"Parameter": "active_adduct_compatible_delta_checks", "Value": "; ".join([name for name, _mass, _role in OBSERVED_ADDUCT_DELTA_RULES])},
        {"Parameter": "observed_adduct_delta_absolute_tolerance_da", "Value": "0.002"},
        {"Parameter": "charge_state_same_neutral_mass_checks", "Value": "[M+H]+/[M+2H]2+ and [M-H]-/[M-2H]2- through neutral-mass matching"},
        {"Parameter": "blank_filtering_rule", "Value": "CD-like ratio rule: max_blank_area > 0 and max_sample_area / max_blank_area <= 5 excludes the compound from MGF and quant table"},
        {"Parameter": "recurrent_raw_filtering_rule", "Value": "DISABLED: features are not removed just because they appear in >= 3 non-blank raw files."},
        {"Parameter": "same_rt_resolving_rule", "Value": "coeluting related ions within delta RT <= 0.01 min are collapsed before MGF export only if the two features are present in at least one same non-blank raw file; MS2-child edges are direct A-vs-B evidence: shared children can be annotated under all direct parents but cannot bridge/fuse parent features"},
    ])
    if errors:
        err_df = pd.DataFrame({"Parameter": [f"warning_{i+1}" for i in range(min(len(errors), 200))], "Value": errors[:200]})
        summary_df = pd.concat([summary_df, err_df], ignore_index=True)

    try:
        with pd.ExcelWriter(output_audit_path, engine="openpyxl") as writer:
            feature_labels_df.to_excel(writer, sheet_name="Feature labels", index=False)
            removed_rows_df.to_excel(writer, sheet_name="Removed rows", index=False)
            relations_df.to_excel(writer, sheet_name="Relations", index=False)
            resolved_compounds_df.to_excel(writer, sheet_name="Resolved compounds", index=False)
            summary_df.to_excel(writer, sheet_name="Summary", index=False)

            wb = writer.book
            for ws in wb.worksheets:
                ws.freeze_panes = "A2"
                for cell in ws[1]:
                    cell.style = "Headline 4"
                for column_cells in ws.columns:
                    max_len = max(len(str(c.value)) if c.value is not None else 0 for c in column_cells)
                    ws.column_dimensions[column_cells[0].column_letter].width = min(max(max_len + 2, 10), 42)
    except ImportError as exc:
        raise RuntimeError(
            "Writing the audit .xlsx file requires openpyxl. "
            "Install it in the Python environment used by the CD Scripting Node: python -m pip install openpyxl"
        ) from exc


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------


def main() -> int:
    try:
        node_args, cdresult_file, table_paths = load_node_args()
        if not cdresult_file or not os.path.exists(cdresult_file):
            raise RuntimeError(f"Could not find .cdResult file from NODEARGS: {cdresult_file}")

        # Use the .cdResult file name also for the output folder.
        # Example: MyStudy.cdResult -> MyStudy_export/
        result_name = Path(cdresult_file).stem or "cd_result"
        outdir = Path(cdresult_file).parent / f"{result_name}_export"
        outdir.mkdir(parents=True, exist_ok=True)

        cd_input, cd_table_path = find_compounds_table(table_paths)
        study_info_df, study_info_path = find_study_information_table(table_paths)

        required = detect_required_columns(cd_input)
        area_max_col = required.get("area_max")
        calc_mw_col = required.get("calc_mw")
        purity_col = detect_ms2_purity_column(cd_input)
        purity_threshold = 60.0
        sample_cols = detect_sample_area_columns(cd_input, required)
        sample_filenames = [clean_sample_filename(c) for c in sample_cols]
        nonblank_sample_cols, nonblank_sample_filenames, blank_sample_cols, blank_sample_filenames = split_blank_and_nonblank_samples(
            sample_cols, sample_filenames
        )

        results = []
        errors = []

        for i, row in cd_input.iterrows():
            cid = safe_int(row[required["compound_id"]])
            rt_min = safe_float(row[required["rt_min"]])
            precursor_mz = safe_float(row[required["mz"]])
            original_ref_ion = row[required["reference_ion"]] if required.get("reference_ion") else "[Unknown]"
            ref_ion = original_ref_ion
            selected_reference_source = "compound_table_reference_ion"
            selected_associated_feature_id = ""
            # MS2/Isolation Purity is retrieved only after confirming that
            # the row has a recoverable MS2 spectrum. For no-MS2 audit rows,
            # these fields stay empty because purity is not applicable to the
            # exported MS2 evidence.
            ms2_purity_pct = None
            ms2_purity_source = ""

            if cid is None or rt_min is None or precursor_mz is None:
                errors.append(f"Skipped row {i}: missing compound ID, RT, or m/z")
                continue

            # Prefer [M+H]+ or [M-H]- when that ion is present among the Features
            # associated with this Compound Group. This overrides CD's default
            # Reference Ion when CD selected a more intense adduct/in-source ion.
            try:
                preferred = choose_preferred_reference_feature(cid, cdresult_file, original_ref_ion)
            except Exception as e:
                preferred = None
                errors.append(f"Compound ID {cid}: associated feature lookup failed: {e}")

            if preferred is not None:
                preferred_ion = preferred.get("associated_reference_ion", "")
                preferred_mz = safe_float(preferred.get("associated_mz"), None)
                preferred_rt = safe_float(preferred.get("associated_rt_min"), None)
                if preferred_ion:
                    ref_ion = preferred_ion
                if preferred_mz is not None:
                    precursor_mz = preferred_mz
                if preferred_rt is not None:
                    rt_min = preferred_rt
                selected_reference_source = preferred.get("selected_reference_source", "associated_feature_with_direct_ms2")
                selected_associated_feature_id = preferred.get("associated_feature_id", "")

            selected_feature_area_max = safe_float(preferred.get("associated_max_area"), None) if preferred is not None else None
            exported_area_max = safe_float(row.get(area_max_col), None) if area_max_col else None
            audit_area_max = selected_feature_area_max if selected_feature_area_max is not None else exported_area_max

            actual_feature_id = ""
            actual_feature_id_source = ""

            try:
                ms2_df, iso_df = None, None

                # The selected feature must first have direct MS2. If choose_preferred_reference_feature()
                # found such a feature, reuse that exact spectrum so that PEPMASS, ADDUCT,
                # FEATURE_ID and MS2 fragments stay internally consistent.
                if preferred is not None and selected_associated_feature_id not in ["", None]:
                    ms2_df = preferred.get("_direct_ms2_df")
                    iso_df = preferred.get("_direct_iso_df")
                    if ms2_df is None or ms2_df.empty:
                        ms2_df, iso_df = get_ms2_for_consolidated_ion(selected_associated_feature_id, cdresult_file)
                    if ms2_df is not None and not ms2_df.empty:
                        actual_feature_id = selected_associated_feature_id
                        actual_feature_id_source = selected_reference_source

                # If no associated feature with direct MS2 was selected, fall back
                # to the compound-level best MS2 and retrieve the associated feature
                # actually linked to that MS2 spectrum when the CD SQLite schema exposes it.
                if ms2_df is None or ms2_df.empty:
                    ms2_df, iso_df, linked_feature_id = get_best_scan_ms2_with_consolidated_ion_id(cid, cdresult_file)
                    if linked_feature_id not in ["", None]:
                        actual_feature_id = linked_feature_id
                        actual_feature_id_source = "compound_best_ms2_linked_associated_feature"
                    elif ms2_df is not None and not ms2_df.empty:
                        actual_feature_id = cid
                        actual_feature_id_source = "compound_best_ms2_feature_id_unavailable"

            except Exception as e:
                errors.append(f"Compound ID {cid}: MS2 extraction failed: {e}")
                ms2_df = pd.DataFrame(columns=["mz", "intensity"])
                iso_df = pd.DataFrame(columns=["mz", "intensity"])

            if ms2_df is None:
                ms2_df = pd.DataFrame(columns=["mz", "intensity"])
            if iso_df is None:
                iso_df = pd.DataFrame(columns=["mz", "intensity"])

            # For no-MS2 audit rows only, keep a best-effort feature ID for traceability.
            # These rows never enter MGF/quant/resolved compounds.
            if actual_feature_id in ["", None]:
                actual_feature_id = find_actual_associated_feature_id_for_compound(
                    cid, cdresult_file, ref_ion, precursor_mz=precursor_mz, rt_min=rt_min
                )
                actual_feature_id_source = "matched_associated_feature_no_direct_ms2" if actual_feature_id not in ["", None] else ""
            if actual_feature_id in ["", None]:
                actual_feature_id = cid
                actual_feature_id_source = "fallback_cd_compound_id_no_associated_feature_found"

            actual_feature_details = get_associated_feature_details_by_id(cdresult_file, actual_feature_id)
            actual_feature_reference_ion = actual_feature_details.get("actual_feature_reference_ion", ref_ion)
            actual_feature_mz = actual_feature_details.get("actual_feature_mz", precursor_mz)
            actual_feature_rt_min = actual_feature_details.get("actual_feature_rt_min", rt_min)
            actual_feature_area_max = actual_feature_details.get("actual_feature_max_area", None)
            actual_feature_calc_mw = actual_feature_details.get("actual_feature_calc_mw", None)

            # If an MS2 spectrum is linked to a specific associated feature/adduct,
            # make the exported row describe that exact feature. This avoids mismatches
            # such as PEPMASS=[M+H]+ while the MS2 was acquired on [M+Na]+.
            if ms2_df is not None and not ms2_df.empty and actual_feature_details:
                if actual_feature_reference_ion not in ["", None] and not pd.isna(actual_feature_reference_ion):
                    ref_ion = actual_feature_reference_ion
                if actual_feature_mz is not None:
                    precursor_mz = actual_feature_mz
                if actual_feature_rt_min is not None:
                    rt_min = actual_feature_rt_min
                if selected_associated_feature_id in ["", None]:
                    selected_associated_feature_id = actual_feature_id

            exported_calc_mw = safe_float(row.get(calc_mw_col), None) if calc_mw_col else None
            audit_calc_mw = actual_feature_calc_mw if actual_feature_calc_mw is not None else exported_calc_mw
            if actual_feature_area_max is not None:
                audit_area_max = actual_feature_area_max

            has_ms2_flag = int(ms2_df is not None and not ms2_df.empty)
            n_ms2_fragments = int(len(ms2_df) if ms2_df is not None else 0)

            # Retrieve MS2/Isolation Purity only for rows with an actual MS2
            # spectrum. This prevents purity values inherited from compound/ion
            # tables from appearing next to features that do not have MS2.
            if has_ms2_flag and cid is not None:
                if purity_col and purity_col in cd_input.columns:
                    ms2_purity_pct = normalize_purity_percent(row.get(purity_col), None)
                    ms2_purity_source = f"exported:{purity_col}" if ms2_purity_pct is not None else "exported_column_empty"
                else:
                    ms2_purity_pct, ms2_purity_source = find_sqlite_ms2_purity_for_compound(cid, cdresult_file)
            else:
                ms2_purity_pct = None
                ms2_purity_source = ""

            # Track whether the resolver actually changed the ion-type assignment
            # relative to Compound Discoverer's original Reference Ion. This is
            # intentionally independent of selected_reference_source, which records
            # how the representative feature was selected rather than whether the
            # ion label changed.
            representative_ion_reassigned = reference_ion_was_reassigned(original_ref_ion, ref_ion)

            record = row.to_dict()
            record.update({
                "feature_id": cid,
                "Compounds ID": cid,
                "RT_min": rt_min,
                "Precursor_mz": precursor_mz,
                "Reference Ion": ref_ion,
                "Original Reference Ion": original_ref_ion,
                "selected_reference_source": selected_reference_source,
                "representative_ion_reassigned": representative_ion_reassigned,
                "selected_associated_feature_id": selected_associated_feature_id,
                "actual_feature_id": actual_feature_id,
                "actual_feature_id_source": actual_feature_id_source,
                "actual_feature_reference_ion": actual_feature_reference_ion,
                "actual_feature_calc_mw": actual_feature_calc_mw,
                "actual_feature_mz": actual_feature_mz,
                "actual_feature_rt_min": actual_feature_rt_min,
                "_audit_area_max": audit_area_max,
                "_audit_calc_mw": audit_calc_mw,
                "MS2_mz_list": ms2_df["mz"].tolist() if not ms2_df.empty else [],
                "MS2_intensity_list": ms2_df["intensity"].tolist() if not ms2_df.empty else [],
                "Isotopic_mz_list": iso_df["mz"].tolist() if not iso_df.empty else [],
                "Isotopic_intensity_list": iso_df["intensity"].tolist() if not iso_df.empty else [],
                "has_ms2": has_ms2_flag,
                "n_ms2_fragments": n_ms2_fragments,
                "_ms2_purity_pct": ms2_purity_pct,
                "_ms2_purity_source": ms2_purity_source,
            })
            results.append(record)

        results_df = pd.DataFrame(results)
        if results_df.empty:
            raise RuntimeError("No compounds were exported. Check the Compounds table columns and diagnostics.")

        # _ms2_purity_pct is populated only for rows with recoverable MS2,
        # from the exported table when available, otherwise from the .cdResult SQLite database.
        ms2_results_before_blank_df = results_df[results_df["n_ms2_fragments"].astype(int) > 0].copy()
        ms2_results_before_blank_df = ms2_results_before_blank_df.reset_index(drop=True)

        ms2_results_after_purity_df, purity_removed_df, purity_filter_applied = filter_by_ms2_purity(
            ms2_results_before_blank_df, purity_col, threshold=purity_threshold
        )
        ms2_results_after_purity_df = ms2_results_after_purity_df.reset_index(drop=True)
        purity_removed_df = purity_removed_df.reset_index(drop=True)
        # Strict rule: even if no purity values are found, rows are excluded because
        # MS2/Isolation Purity >= threshold is not demonstrable.
        if len(ms2_results_before_blank_df) > 0 and len(ms2_results_after_purity_df) == 0:
            errors.append("Strict MS2 purity filter retained zero MS2-bearing entries. Check that IsolationPurity/MS2 Purity can be retrieved from the .cdResult SQLite database.")

        ms2_results_df, blank_removed_df = filter_out_blank_present_features(
            ms2_results_after_purity_df,
            blank_sample_cols,
            nonblank_cols=nonblank_sample_cols,
            ratio_threshold=5.0,
        )
        ms2_results_df = ms2_results_df.reset_index(drop=True)
        blank_removed_df = blank_removed_df.reset_index(drop=True)

        # Recurrent/non-blank raw-count filtering is intentionally disabled.
        # Valid features may legitimately occur across multiple non-blank samples, so
        # recurrence across samples is not used as an exclusion criterion.
        recurrent_raw_removed_df = ms2_results_df.iloc[0:0].copy()
        ms2_results_df = ms2_results_df.reset_index(drop=True)

        if nonblank_sample_cols:
            area_frame = ms2_results_df[nonblank_sample_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0)
            ms2_results_df["_max_nonblank_area"] = area_frame.max(axis=1)
        else:
            ms2_results_df["_max_nonblank_area"] = 0.0

        # Collapse coeluting related ions before writing MGF/quant files.
        ms2_collapsed_df, same_rt_removed_df, same_rt_relation_df = collapse_rt_related_entries(
            ms2_results_df,
            rt_tol_min=0.01,
            neutral_ppm=10.0,
            frag_ppm=5.0,
            sample_cols=nonblank_sample_cols,
            sample_filenames=nonblank_sample_filenames,
        )
        ms2_collapsed_df = ms2_collapsed_df.reset_index(drop=True)
        same_rt_removed_df = same_rt_removed_df.reset_index(drop=True)

        ms2_collapsed_df["feature_id"] = range(1, len(ms2_collapsed_df) + 1)

        # Use the .cdResult file name as prefix for the four final export files.
        output_mgf = outdir / f"{result_name}_spectra.mgf"
        output_quant = outdir / f"{result_name}_quant.csv"
        output_metadata = outdir / f"{result_name}_metadata.tsv"
        output_audit = outdir / f"{result_name}_audit.xlsx"

        n_mgf = write_mgf(
            ms2_collapsed_df,
            output_mgf,
            sample_cols=nonblank_sample_cols,
            sample_filenames=nonblank_sample_filenames,
            min_ms2_peaks=1,
        )
        quant_df = write_quant_table(ms2_collapsed_df, output_quant, nonblank_sample_cols, nonblank_sample_filenames)
        metadata_df = write_metadata(output_metadata, nonblank_sample_filenames, study_info_df)
        write_feature_resolver_audit(
            results_df=results_df,
            selected_df=ms2_collapsed_df,
            blank_removed_df=blank_removed_df,
            recurrent_raw_removed_df=recurrent_raw_removed_df,
            purity_removed_df=purity_removed_df,
            same_rt_removed_df=same_rt_removed_df,
            same_rt_relation_df=same_rt_relation_df,
            output_audit_path=output_audit,
            sample_cols=sample_cols,
            nonblank_sample_cols=nonblank_sample_cols,
            blank_sample_cols=blank_sample_cols,
            sample_filenames=sample_filenames,
            blank_sample_filenames=blank_sample_filenames,
            area_max_col=area_max_col,
            calc_mw_col=calc_mw_col,
            metadata_df=metadata_df,
            study_info_path=study_info_path,
            purity_col=purity_col,
            purity_filter_applied=purity_filter_applied,
            purity_threshold=purity_threshold,
            errors=errors,
        )

        report_lines = [
            "CD to MGF export completed",
            f"Input CD table: {cd_table_path}",
            f"Study Information table: {study_info_path}",
            f"CD result file: {cdresult_file}",
            f"Output folder: {outdir}",
            f"CD entries read from Compounds table: {len(results_df)}",
            f"Entries with MS2 before purity/blank filtering: {len(ms2_results_before_blank_df)}",
            f"MS2 purity column detected in exported table: {purity_col or 'none'}",
            f"MS2 purity strict filter applied: {purity_filter_applied}",
            f"MS2-bearing entries removed because purity is missing or < {purity_threshold:g}: {len(purity_removed_df)}",
            f"MS2-bearing entries removed because present in blank: {len(blank_removed_df)}",
            "MS2-bearing entries removed by recurrent non-blank raw-count filter: 0 (filter disabled)",
            f"MS2-bearing entries retained after purity/blank/recurrent-raw filtering: {len(ms2_results_df)}",
            f"Same-RT related MS2 entries removed before MGF export (same-raw only, no child-bridging): {len(same_rt_removed_df)}",
            f"Resolved MGF representative entries after same-RT collapsing: {len(ms2_collapsed_df)}",
            f"Representative ions reassigned relative to original CD Reference Ion: {int(pd.Series(ms2_collapsed_df.get('representative_ion_reassigned', False)).fillna(False).astype(bool).sum())}",
            f"Entries without MS2 excluded from quant table: {len(results_df) - len(ms2_results_before_blank_df)}",
            f"MS2 spectra written to MGF after blank/recurrent-raw filtering and same-RT resolving: {n_mgf}",
            f"Quant table rows after same-RT resolving: {len(quant_df)}",
            f"Metadata rows: {len(metadata_df)}",
            f"Study Information ATTRIBUTE columns written: {metadata_df.attrs.get('study_info_attribute_columns', 0)}",
            f"Metadata unmatched filenames: {'; '.join(metadata_df.attrs.get('metadata_unmatched_filenames', [])) or 'none'}",
            f"Area Max column detected for audit area: {area_max_col or 'none'}",
            f"Calc MW column detected for audit calc_mw fallback: {calc_mw_col or 'none'}",
            f"Sample columns detected before blank removal: {len(sample_cols)}",
            f"Blank sample columns removed from quant table: {len(blank_sample_cols)}",
            f"Non-blank sample columns retained in quant table: {len(nonblank_sample_cols)}",
            f"Blank samples detected: {', '.join(blank_sample_filenames) if blank_sample_filenames else 'none'}",
            "",
            "Final output files:",
            f"- {output_mgf}",
            f"- {output_quant}",
            f"- {output_metadata}",
            f"- {output_audit}",
            "",
            "Notes:",
            "- Only the four final files above are written.",
            "- The quant table contains only representative entries with MS/MS spectra, MS2/Isolation Purity >= 60, and not removed by the CD-like blank ratio rule.",
            "- representative_ion_reassigned is based on the canonicalized original vs final Reference Ion labels and is independent of selected_reference_source.",
            "- Rows with missing MS2/Isolation Purity are excluded by the strict purity rule.",
            f"- MS2 Purity >= {purity_threshold:g} is applied from the exported Compounds table when available, otherwise from .cdResult SQLite if found.",
            "- Blank/background removal uses: max_blank_area > 0 and max_sample_area / max_blank_area <= 5.",
            "- No recurrent non-blank raw-count filter is applied because valid features may legitimately occur across multiple non-blank samples.",
            "- MS2-child resolver rule: child/fragment edges are direct only; shared children may be annotated under all direct parent candidates but do not bridge/merge separate parent features and are not exported as final MGF rows.",
            "- Same-RT related entries within delta RT <= 0.01 min are collapsed before MGF export, except ambiguous shared-child bridges.",
            f"- Active mass-difference rules: {', '.join([name for name, _mass in MASS_DIFFERENCE_RULES])}.",
            f"- Active adduct-compatible delta checks: {', '.join([name for name, _mass, _role in OBSERVED_ADDUCT_DELTA_RULES])}.",
            "- In the MGF, SCANS matches quant table 'row ID'; FEATURE_ID reports the associated CD feature/ion ID when available.",
            "- The MGF contains ADDUCT and FILENAME; ION is not written.",
            "- FILENAME is built from non-blank area columns with area > 0 and separated by semicolon.",
            "- Quant sample columns are written as '<raw filename> Peak area'.",
            "- Metadata is written from the CD Study Information table; File Name becomes filename and all other columns become ATTRIBUTE_*.",
        ]
        if errors:
            report_lines.extend(["", "Warnings/errors:"] + errors[:200])

        print("\n".join(report_lines))
        return 0

    except Exception as e:
        err_dir = Path.cwd() / "cd_mgf_export_error"
        err_dir.mkdir(exist_ok=True)
        with open(err_dir / "error.txt", "w", encoding="utf-8") as f:
            f.write(str(e) + "\n\n")
            f.write(traceback.format_exc())
        print("ERROR:", e)
        print(traceback.format_exc())
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
